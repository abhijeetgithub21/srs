<?php 
class Carousel extends CI_Model {
 public function __construct(){
 	parent::__construct();
 }	

 public function get_all_records()
 {
 	return $this->db->select('*')->from('carousel')->where('id',1)->get()->result_array();
 }

 

}

?>