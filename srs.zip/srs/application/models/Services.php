<?php 
class Services extends CI_Model {
 public function __construct(){
 	parent::__construct();
 }	

 public function get_all_services()
 {
 	return $this->db->select('*')->from('services')->get()->result_array();
 }

}

?>