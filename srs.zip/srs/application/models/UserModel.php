<?php 
class UserModel extends CI_Model {
 public function __construct(){
 	parent::__construct();
 }	

 public function settings($value='')
 {
 	return $this->db->select('*')->from('settings')->where('id','1')->get()->result_array();
 }

 public function get_all_users($value='')
 {
 	return $this->db->select('*')->from('users')->get()->result_array();
 }

}

?>