<?php 
class About extends CI_Model {
 public function __construct(){
 	parent::__construct();
 }	
     public function get_all_about_details()
     {
     	return $this->db->select('*')->from('about')->where('id','1')->get()->result_array();
     }
     

 

}

?>