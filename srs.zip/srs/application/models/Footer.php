<?php 
class Footer extends CI_Model {
 public function __construct(){
 	parent::__construct();
 }	
     public function get_all_footer_details()
     {
     	return $this->db->select('*')->from('footer')->where('id','1')->get()->result_array();
     }
     

 

}

?>