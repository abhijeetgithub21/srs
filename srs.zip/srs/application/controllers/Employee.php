<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Employee extends CI_Controller
{
    public function __construct() {
        parent::__construct();
        $this->load->model('UserModel');
        if($this->session->userdata('login') != "b"){
            redirect('employeelogin');
        }
    }

    public function index(){
        $id = $_SESSION['id'];
        $data['users'] = $this->db->from('users')->where('id',$id)->get()->result_array();
        $data['page_title'] = 'Employee Dashboard';
        $this->load->view('employee/dashboard',$data);
    }
     public function dashboard(){
        $id = $_SESSION['id'];
        $data['users'] = $this->db->from('users')->where('id',$id)->get()->result_array();
        $data['page_title'] = 'Employee Dashboard';
        $this->load->view('employee/'.__FUNCTION__,$data);
    }
    public function setting()
    {
        $id = $_SESSION['id'];
        $data['users'] = $this->db->from('users')->where('id',$id)->get()->result_array();
        $data['page_title'] = 'Employee Settings';
        $this->load->view('employee/'.__FUNCTION__,$data);
    }
    public function update_detail($id){
        $data['name'] = $this->input->post('name');
        $data['email'] = $this->input->post('email');
        $data['mobile'] = $this->input->post('mobile');
        $data['address'] = $this->input->post('address');

        $this->db->where('id',$id);
        $update_query = $this->db->update('users',$data);
        if($update_query){
            $this->session->set_flashdata('msg','Data Successfully Updated');   
            }else{
                $this->session->set_flashdata('msg','Something went wrong'); 
            }
            redirect('employee/setting');
    }
    public function change_pass($id)
    {
        // $this->db->select('*');
        // $this->db->where('id',$this->input->post('email'));
        // $query = $this->db->get('users');
        // $num = $query->num_rows();

        $num = $this->db->select('*')->where('id',$id)->get('users')->num_rows();
        if($num > 0){
            $old_pass = $this->input->post('old_pass');
            $query = $this->db->from('users')->where('id',$id)->get()->row();
            // echo $old_pass.$query->password;exit;
            if($query->password === $old_pass){
                $new_pass = $this->input->post('new_pass');
                $c_new_pass = $this->input->post('c_new_pass');
                if($new_pass == $c_new_pass){
                    $data['password'] = $new_pass;
                    $udpate_query = $this->db->where('id',$id)->update('users',$data);
                    if($udpate_query){
                        $this->session->set_flashdata("msg","Password Successfully Changed");
                    }else{
                        $this->session->set_flashdata("msg","Passowrd didn't change");
                    }
                }else{
                     $this->session->set_flashdata("msg","new passwords doesn't match");
                }
            }else{
                $this->session->set_flashdata("msg","Current password doesn't match");
            }
        }else{
            $this->session->set_flashdata('msg','Something went wrong');
        }
        redirect('employee/setting');
    }

    public function manage_seed_category(){
        $id = $_SESSION['id'];
        $data['users'] = $this->db->from('users')->where('id',$id)->get()->result_array();
        $data['seed_category'] = $this->db->from('seed_category')->get()->result_array();
        $data['settings'] = $this->db->from('settings')->get()->result_array();
        $data['settings'] = $this->UserModel->settings();
        $data['page_title'] = 'Seed Category';
        $this->load->view('employee/'.__FUNCTION__, $data);
    }
     public function manage_seeds(){
        $id = $_SESSION['id'];
        $data['users'] = $this->db->from('users')->where('id',$id)->get()->result_array();
        $data['seed_category'] = $this->db->from('seed_category')->get()->result_array();
        $data['seeds'] = $this->db->from('seeds')->get()->result_array();
        $data['settings'] = $this->db->from('settings')->get()->result_array();
        $data['settings'] = $this->UserModel->settings();
        $data['page_title'] = 'Seeds';
        $this->load->view('employee/'.__FUNCTION__, $data);
    }
    public function edit_seed($sid){
        $id = $_SESSION['id'];
        $data['users'] = $this->db->from('users')->where('id',$id)->get()->result_array();
        $data['seed_category'] = $this->db->from('seed_category')->get()->result_array();
        $data['seeds'] = $this->db->from('seeds')->where('id',$sid)->get()->result_array();
        $data['settings'] = $this->db->from('settings')->get()->result_array();
        $data['settings'] = $this->UserModel->settings();
        $data['page_title'] = 'Seeds';
        $this->load->view('employee/'.__FUNCTION__,$data);
    }
    public function edit_seed_category($sid)
    {
        $id = $_SESSION['id'];
        $data['users'] = $this->db->from('users')->where('id',$id)->get()->result_array();
        $data['seed_category'] = $this->db->where('id',$sid)->from('seed_category')->get()->result_array();
        $data['settings'] = $this->db->from('settings')->get()->result_array();
        $data['settings'] = $this->UserModel->settings();
        $data['page_title'] = 'Edit Seed Category';
        $this->load->view('employee/'.__FUNCTION__,$data);
    }
    public function add_seed_category(){
        $data = array(
            'name' => $this->input->post('name'),
        );
        $insert_query = $this->db->insert('seed_category', $data);
               
        if($insert_query){
            $this->session->set_flashdata('msg','Data Successfully Updated');
        }else{
            $this->session->set_flashdata('msg','Something went wrong!');
        }
        return redirect('employee/manage_seed_category');
    }
    public function delete_seed_category($id){
        $this->db->where('id',$id);
        $delete_query = $this->db->delete('seed_category'); 
        if($delete_query){
            $this->session->set_flashdata('msg','category Deleted Successfully');
        }else{
            $this->session->set_flashdata('error','Sowething Went Wrong!');
        };
        return redirect('employee/manage_seed_category');
    }
    public function delete_seed($id){
        $this->db->where('id',$id);
        $delete_query = $this->db->delete('seeds'); 
        if($delete_query){
            $this->session->set_flashdata('msg','Seeds Deleted Successfully');
        }else{
            $this->session->set_flashdata('error','Sowething Went Wrong!');
        };
        return redirect('employee/manage_seeds');
    }
    public function add_seed(){
        $name = $this->input->post('name');
        $category_id = $this->input->post('category');
        $expiry_date = $this->input->post('expiry_date');
        $quantity = $this->input->post('quantity');

        $config['upload_path']          = './_assets/upload/seeds';
        $config['allowed_types']        = 'jpg|png';
        // $config['file_name'] = date();

        $this->load->library('upload', $config);

        if ( ! $this->upload->do_upload('image'))
        {
                $error = array('error' => $this->upload->display_errors());

                $this->load->view('manage_seeds', $error);
        }
        else
        {
                $data =  $this->upload->data();
                $img = $data['file_name'];
        }

        $data  = array(
            'name' => $name,
            'category_id' => $category_id,
            'expiry_date' => $expiry_date,
            'image' => $img,
            'quantity' => $quantity,
        );


         $insert_query = $this->db->insert('seeds', $data);

        if($insert_query){
            $this->session->set_flashdata('msg','Data inserted Successfully!');
        }else{
            $this->session->set_flashdata('msg','Something went wrong!');
        }
        redirect('employee/manage_seeds');
    }
    public function update_seed($id)
    {
        $name = $this->input->post('name');
        $category_id = $this->input->post('category');
        $expiry_date = $this->input->post('expiry_date');
        $quantity = $this->input->post('quantity');
        $old_image = $this->input->post('old_image');

        $photo = $_FILES['image']['name'];
        
        if($photo != ""){
            $photoExt1 = @end(explode('.',$photo));
            $phototest1 = strtolower($photoExt1);
            $new_photo = time().'.'.$phototest1;
            $photo_path = './_assets/upload/seeds/'.$new_photo;
            move_uploaded_file($_FILES['image']['tmp_name'],$photo_path);
        }
        if($photo==''){
            $new_photo = $old_photo;
        }

        if($new_image == ""){
            $new_image = $old_image;
        }

         $data  = array(
            'name' => $name,
            'category_id' => $category_id,
            'expiry_date' => $expiry_date,
            'image' => $new_image,
            'quantity' => $quantity,
        );

         $this->db->where('id',$id);
         $update_query = $this->db->update('seeds', $data);

        if($update_query){
            $this->session->set_flashdata('msg','Data updated successfully!');
        }else{
            $this->session->set_flashdata('msg','Something went wrong!');
        }
        redirect('employee/manage_seeds');



    }
    public function update_seed_category($id)
    {
        $data = array('name'=>$this->input->post('name'));
        $this->db->where('id',$id);
         $update_query = $this->db->update('seed_category', $data);

        if($update_query){
            $this->session->set_flashdata('msg','Data updated successfully!');
        }else{
            $this->session->set_flashdata('msg','Something went wrong!');
        }
        redirect('employee/manage_seed_category');
    }

    public function add_inventory()
    {
        $seed_id = $this->input->post('seed');
        $name = $this->input->post('name');
        $email = $this->input->post('email');
        $mobile = $this->input->post('mobile');
        $address = $this->input->post('address');
        $quantity = $this->input->post('quantity');

        $query = $this->db->from('seeds')->where('id',$seed_id)->get()->row();
        $seed_category_id =  $query->category_id;
        $expiry_date = $query->expiry_date;
        date_default_timezone_set("Asia/Calcutta");
        $date = date('Y-m-d');
        $time = date("H:i:s");
        $invoice_number = "invoice@ ".rand(10000000,99999999);
        $inventory_status = $this->input->post('inventory_status');

        $get_quantity_from_seed = $this->db->from('seeds')->where('id',$seed_id)->get()->row();
        $quantityfromseed = $get_quantity_from_seed->quantity;
        if($inventory_status == 1 ){
            $totalquantity =  $quantityfromseed+$quantity;  
        }else{
             if($quantityfromseed < $quantity){
                $this->session->set_flashdata('msg','You can not sell this seed because quantity is less than your input!');
                 redirect('employee/seed_inventry');exit;
            }else{
                $totalquantity =  $quantityfromseed-$quantity;
            }
            
        }
        $data1 = array(
            'quantity' => $totalquantity,
        );
        $update_query = $this->db->where('id',$seed_id)->update('seeds',$data1);
        if($update_query){
                $data = array(
                    'seed_category_id' => $seed_category_id,
                    'seed_id' => $seed_id,
                    'date' => $date,
                    'time'=> $time,
                    'expiry_date' => $expiry_date,
                    'name' => $name,
                    'email' => $email,
                    'mobile' => $mobile,
                    'address' => $address,
                    'quantity' => $quantity,
                    'invoice_number' => $invoice_number,
                );

                // print_r($data);exit;

                $insert_query = $this->db->insert('seed_inventry', $data);
                if($insert_query){
                    $this->session->set_flashdata('msg','Data inserted successfully');
                }else{
                    $this->session->set_flashdata('msg','Something went wrong');
                }
        }else{
            $this->session->set_flashdata('msg','Something went wrong');
        }
        
        redirect('employee/seed_inventry');
    }

    public function delete_inventory($id)
    {
        $this->db->where('id',$id);
        $delete_query = $this->db->delete('seed_inventry');
        
        if($delete_query){
            $this->session->set_flashdata('msg','Data deleted successfully');
        }else{
            $this->session->set_flashdata('msg','Something went wrong!');    
        }
        redirect('employee/seed_inventry');
    }
    public function seed_inventry(){
        $id = $_SESSION['id'];
        $data['users'] = $this->db->from('users')->where('id',$id)->get()->result_array();
        $data['seed_inventry'] = $this->db->from('seed_inventry')->get()->result_array();
        $data['seed_category'] = $this->db->from('seed_category')->get()->result_array();
        $data['seeds'] = $this->db->from('seeds')->get()->result_array();
        $data['settings'] = $this->db->from('settings')->get()->result_array();
        $data['settings'] = $this->UserModel->settings();
        $data['page_title'] = 'Seed Inventry';
        $this->load->view('employee/'.__FUNCTION__,$data);
    }






































}
    
