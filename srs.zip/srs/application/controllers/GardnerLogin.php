<?php
defined('BASEPATH') or exit('No direct script access allowed');

class GardnerLogin extends CI_Controller
{
    public function __construct() {
        parent::__construct();
        $this->load->helper(array('form', 'url'));
        $this->load->library(['form_validation','session']);
        $this->load->model('UserModel');
        $this->load->database();
    }
    public function index()
    {
        $this->load->view('gardner/login');
    }
    

    public function login() {

            $username = $this->input->post('email');
            $password = $this->input->post('password');
            $user = $this->db->get_where('users',['email' => $username,'password'=>$password,'status'=>1,'access'=>3])->row();
            
            if(!$user) {
                $this->session->set_flashdata('login_error', 'Please check your email or password and try again.', 300);
                redirect('gardner');
            }

    
            if($password !== $user->password) {
                $this->session->set_flashdata('login_error', 'Please check your email or password and try again.', 300);
                redirect('gardner');
            }

             $data = array(
                    'id' => $user->id,
                    'name' => $user->name,
                    'email' => $email,
                    'mobile' => $mobile,
                    'login'=>'c',
                    );

                
            $this->session->set_userdata($data);
            redirect('gardner',$data);
    }
    public function logout(){
        $this->session->sess_destroy();
        redirect('/');
    }
    

}
