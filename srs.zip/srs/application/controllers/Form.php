<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Form extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->helper(array('form', 'url'));
        $this->load->library(['form_validation']);
        $this->load->database();
        $this->load->model('UserModel');
         $this->load->model('Services');
         $this->load->model('Footer');
    }
    public function manage_site_function(){
        // $old_photo = $this->input->post('old_photo');
        // $photo = $_FILES['new_photo']['name'];
        
        // if($photo != ""){
        //     $photoExt1 = @end(explode('.',$photo));
        //     $phototest1 = strtolower($photoExt1);
        //     $new_photo = time().'.'.$phototest1;
        //     $photo_path = './assets/wp-content/uploads/2020/05/'.$new_photo;
        //     move_uploaded_file($_FILES['new_photo']['tmp_name'],$photo_path);
        // }
        // if($photo==''){
        //     $new_photo = $old_photo;
        // }
        
        $website_name = $this->input->post('website_name');
        $website_email = $this->input->post('website_email');
        $website_mobile = $this->input->post('mobile');
        $website_address = $this->input->post('address');

        $admin_name = $this->input->post('admin_name');
        $admin_email = $this->input->post('admin_email');
        $admin_mobile = $this->input->post('admin_mobile');
        $password = $this->input->post('password');

        $data1 = array(
            'name' => $website_name,
            'email' => $website_email,
            'mobile_number' =>  $website_mobile,
            'address' =>    $website_address,
            'o_name' => $admin_name,
        );
        $update_website = $this->db->where('id',1)->update('settings', $data1);
        if($update_website){
                    $data2 = array(
                'name' => $admin_name,
                'email' => $admin_email,
                'mobile' =>   $admin_mobile,
                'password' => $password,
                    );
                     $update_admin = $this->db->where(array('status'=>1,'access'=>1))->update('users',$data2);
                     if($update_admin){
                    $this->session->set_flashdata('msg','Data Successfully Updated');
                }else{
                    $this->session->set_flashdata('msg','Something went wrong');
                }
        }else{
            $this->session->set_flashdata('msg','Something not updated');
        }    
             return redirect('dashboard/administrator');
    }
    public function update_links(){
         $data = array(
            'twiter' => $this->input->post('twiter'),
            'facebook' => $this->input->post('facebook'),
            'instagram' =>  $this->input->post('instagram'),
        );
        
                $update_query = $this->db->where('id',1)->update('settings', $data);
               
                if($update_website & $update_admin){
                    $this->session->set_flashdata('msg','Data Successfully Updated');
                }
                return redirect('dashboard/administrator');
    }
    public function add_gardner(){
        $data = array(
            'name' => $this->input->post('name'),
            'email' => $this->input->post('email'),
            'mobile' => $this->input->post('mobile'),
            'access' => 3,
            'status' =>1,
            'password' => 'admin@123',
        ); 
        $this->db->select('*');
        $this->db->where('email',$this->input->post('email'));
        $query = $this->db->get('users');
        $num = $query->num_rows();
            if($num > 0){
                $this->session->set_flashdata('msg','Email id or mobile number already registrered');
               
            }else{
                $insert_query = $this->db->insert('users',$data);
                
                        if($insert_query){
                            $this->session->set_flashdata('msg','Data Successfully Updated');
                        }

            }
       
                return redirect('dashboard/gardners');

    }
    public function add_employee(){
        $data = array(
            'name' => $this->input->post('name'),
            'email' => $this->input->post('email'),
            'mobile' => $this->input->post('mobile'),
            'access' => 2,
            'status' =>1,
            'password'=>'admin@123',
        ); 
        $this->db->select('*');
        $this->db->where('email',$this->input->post('email'));
        $query = $this->db->get('users');
        $num = $query->num_rows();
            if($num > 0){
                $this->session->set_flashdata('msg','Email id or mobile number already registrered');
               
            }else{
                $insert_query = $this->db->insert('users',$data);
                
                        if($insert_query){
                            $this->session->set_flashdata('msg','Data Successfully Updated');
                        }

            }
        return redirect('dashboard/employees');

    }
    public function delete_employee($id){
         $this->db->where('id', $id);
        $delete_service = $this->db->delete('users'); 
        if($delete_service){
            $this->session->set_flashdata('msg','Data Successfully Deleted');
        }else{
            $this->session->set_flashdata('error','Sowething Went Wrong!');
        };
        return redirect('dashboard/employees');
    }
    public function delete_gardner($id){
         $this->db->where('id', $id);
        $delete_service = $this->db->delete('users'); 
        if($delete_service){
            $this->session->set_flashdata('msg','Page Deleted Successfully');
        }else{
            $this->session->set_flashdata('error','Sowething Went Wrong!');
        };
        return redirect('dashboard/gardners');
    }
    public function add_page()
    {
        $p_name =  $this->input->post('name');
        $content = $this->input->post('content');
        $data = array(
            'p_name' => $p_name,
            'content' => $content,
        ); 

        $check = $this->db->get_where('pages',array('p_name',$p_name));
        if($check->num_rows() > 0 ){
            $this->session->set_flashdata('msg','Page already exists');
        }else{
            $insert_query = $this->db->insert('pages',$data);
            if($insert_query){
                $this->session->set_flashdata('msg','Data Inserted Successfully');
            }else{
                $this->session->set_flashdata('msg','Something went wrong');
            }
        }
        return redirect('dashboard/manage_page');
        

    }
    public function delete_page($id)
    {       
        $page = $this->db->from('pages')->where('p_id',$id)->get()->row();
        $p_name = $page->p_name;
        $this->db->where('page_id',$id);
        $menu_delete = $this->db->delete('category');
        if($menu_delete){
            $query = $this->db->where('page_id',$id)->delete('footer_links');
            if($query){
                $delete_menu = $this->db->where('category_name', $p_name)->delete('category'); 
                if($delete_menu){
                    $delete_query = $this->db->where('p_id', $id)->delete('pages'); 
                    if($delete_query){
                        $this->session->set_flashdata('msg','Data Successfully Deleted');
                    } 
                }else{
                    $this->session->set_flashdata('error','Sowething Went Wrong!');
                };
            }else{
                $this->session->set_flashdata('error','Sowething Went Wrong!');
            }
        }else{
            $this->session->set_flashdata('error','Sowething Went Wrong!');
        }
        return redirect('dashboard/manage_page');
    }
    public function update_page($id)
    {
    
        $p_name =  $this->input->post('name');
        $content = $this->input->post('content');
        $data = array(
            'p_name' => $p_name,
            'content' => $content,
        );
            
            $data2 = array('name' => $p_name,);
            $data1 = array('category_name' => $p_name,);
            $menu = $this->db->where('page_id',$id)->update('category',$data1);
            if($menu){
                 $query = $this->db->where('page_id',$id)->update('footer_links',$data2);
            if($query){
                     $insert_query = $this->db->where('p_id',$id)->update('pages',$data);
                    if($insert_query){
                        $this->session->set_flashdata('msg','Data Updated Successfully');
                    }else{
                        $this->session->set_flashdata('msg','Something went wrong');
                    }
                }else{
                    $this->session->set_flashdata('msg','Something went wrong');
                }
            }else{
                $this->session->set_flashdata('msg','Something went wrong');
            }

        return redirect('dashboard/manage_page');
    }
    public function add_to_menu($id)
    {
        $page = $this->db->from('pages')->where('p_id',$id)->get()->row();
        $p_name = $page->p_name;
        $url = 'welcome/page/'.$id;
        $data = array(
            'category_name' => $p_name,
            'category_link'=> $url,
            'page_id' => $id,
        );       
        $inserted_data = $this->db->insert('category', $data);
        
        if($inserted_data){
            $this->session->set_flashdata('msg','Data Successfully Added to Menu');
        }else{
            $this->session->set_flashdata('msg','Check your page is already added');
        };
        return redirect('dashboard/manage_page');
    }
    public function add_to_footer($id)
    {
        $page = $this->db->from('pages')->where('p_id',$id)->get()->row();
        $p_name = $page->p_name;
        $page_id = $page->p_id;
        $url = 'welcome/page/'.$id;
        $data = array(
            'page_id' => $page_id,
            'name' => $p_name,
            'link'=> $url,
        );       
        $inserted_data = $this->db->insert('footer_links', $data);
        
        if($inserted_data){
            $this->session->set_flashdata('msg','Data Successfully Added to Footer');
        }else{
            $this->session->set_flashdata('msg','Check your page is already added');
        };
        return redirect('dashboard/manage_page');
    }
    public function top_bar_title()
    {
        $data = array(
            'top_bar_title' => $this->input->post('top_bar_title'),
        );
        $update_query = $this->db->where('id',1)->update('settings', $data);
               
        if($update_query){
            $this->session->set_flashdata('msg','Data Successfully Updated');
        }else{
            $this->session->set_flashdata('msg','Something went wrong!');
        }
        return redirect('dashboard/administrator');

    }
    public function google_map()
    {
        $data = array(
            'google_map' => $this->input->post('google_map'),
        );
        $update_query = $this->db->where('id',1)->update('settings', $data);
               
        if($update_query){
            $this->session->set_flashdata('msg','Data Successfully Updated');
        }else{
            $this->session->set_flashdata('msg','Something went wrong!');
        }
        return redirect('dashboard/administrator');

    }
    public function add_seed_category(){
        $data = array(
            'name' => $this->input->post('name'),
        );
        $insert_query = $this->db->insert('seed_category', $data);
               
        if($insert_query){
            $this->session->set_flashdata('msg','Data Successfully Updated');
        }else{
            $this->session->set_flashdata('msg','Something went wrong!');
        }
        return redirect('dashboard/manage_seed_category');
    }
    public function delete_seed_category($id){
        $this->db->where('id',$id);
        $delete_query = $this->db->delete('seed_category'); 
        if($delete_query){
            $this->session->set_flashdata('msg','category Deleted Successfully');
        }else{
            $this->session->set_flashdata('error','Sowething Went Wrong!');
        };
        return redirect('dashboard/manage_seed_category');
    }
    public function delete_seed($id){
        $this->db->where('id',$id);
        $delete_query = $this->db->delete('seeds'); 
        if($delete_query){
            $this->session->set_flashdata('msg','Seeds Deleted Successfully');
        }else{
            $this->session->set_flashdata('error','Sowething Went Wrong!');
        };
        return redirect('dashboard/manage_seeds');
    }
    public function add_seed(){
        $name = $this->input->post('name');
        $category_id = $this->input->post('category');
        $expiry_date = $this->input->post('expiry_date');
        $quantity = $this->input->post('quantity');

        $config['upload_path']          = './_assets/upload/seeds';
        $config['allowed_types']        = 'jpg|png';
        // $config['file_name'] = date();

        $this->load->library('upload', $config);

        if ( ! $this->upload->do_upload('image'))
        {
                $error = array('error' => $this->upload->display_errors());

                $this->load->view('manage_seeds', $error);
        }
        else
        {
                $data =  $this->upload->data();
                $img = $data['file_name'];
        }

        $data  = array(
            'name' => $name,
            'category_id' => $category_id,
            'expiry_date' => $expiry_date,
            'image' => $img,
            'quantity' => $quantity,
        );


         $insert_query = $this->db->insert('seeds', $data);

        if($insert_query){
            $this->session->set_flashdata('msg','Data inserted Successfully!');
        }else{
            $this->session->set_flashdata('msg','Something went wrong!');
        }
        redirect('dashboard/manage_seeds');
    }
    public function update_seed($id)
    {
        $name = $this->input->post('name');
        $category_id = $this->input->post('category');
        $expiry_date = $this->input->post('expiry_date');
        $quantity = $this->input->post('quantity');
        $old_image = $this->input->post('old_image');

        $photo = $_FILES['image']['name'];
        
        if($photo != ""){
            $photoExt1 = @end(explode('.',$photo));
            $phototest1 = strtolower($photoExt1);
            $new_photo = time().'.'.$phototest1;
            $photo_path = './_assets/upload/seeds/'.$new_photo;
            move_uploaded_file($_FILES['image']['tmp_name'],$photo_path);
        }
        if($photo==''){
            $new_photo = $old_photo;
        }

        if($new_image == ""){
            $new_image = $old_image;
        }

         $data  = array(
            'name' => $name,
            'category_id' => $category_id,
            'expiry_date' => $expiry_date,
            'image' => $new_image,
            'quantity' => $quantity,
        );

         $this->db->where('id',$id);
         $update_query = $this->db->update('seeds', $data);

        if($update_query){
            $this->session->set_flashdata('msg','Data updated successfully!');
        }else{
            $this->session->set_flashdata('msg','Something went wrong!');
        }
        redirect('dashboard/manage_seeds');



    }
    public function update_seed_category($id)
    {
        $data = array('name'=>$this->input->post('name'));
        $this->db->where('id',$id);
         $update_query = $this->db->update('seed_category', $data);

        if($update_query){
            $this->session->set_flashdata('msg','Data updated successfully!');
        }else{
            $this->session->set_flashdata('msg','Something went wrong!');
        }
        redirect('dashboard/manage_seed_category');
    }
    public function update_gardner($id){
        $data['name'] = $this->input->post('name');
        $data['email'] = $this->input->post('email');
        $data['mobile'] = $this->input->post('mobile');
        $data['address'] = $this->input->post('address');

        $this->db->where('id',$id);
        $update_query = $this->db->update('users',$data);
        if($update_query){
            $this->session->set_flashdata('msg','Data Successfully Updated');   
            }else{
                $this->session->set_flashdata('msg','Something went wrong'); 
            }
            redirect('dashboard/gardners');
    }
    public function update_employee($id){
        $data['name'] = $this->input->post('name');
        $data['email'] = $this->input->post('email');
        $data['mobile'] = $this->input->post('mobile');
        $data['address'] = $this->input->post('address');

        $this->db->where('id',$id);
        $update_query = $this->db->update('users',$data);
        if($update_query){
            $this->session->set_flashdata('msg','Data Successfully Updated');   
            }else{
                $this->session->set_flashdata('msg','Something went wrong'); 
            }
            redirect('dashboard/employees');
    }

public function add_carousel(){
       // $img = $_FILES['image']['name'];
       // $photoExt1 = @end(explode('.',$photo));
    //     $phototest1 = strtolower($photoExt1);
    //     $new_photo = time().'.'.$phototest1;
    //     $photo_path = './assets/images/'.$new_photo;
    //     move_uploaded_file($_FILES['image']['tmp_name'],$photo_path);
        
        $config['upload_path']  = './_assets/upload/carousel';
        $config['allowed_types'] = 'jpg|jpeg|png|gif';
        $config['max_size']  = 0;

        $this->load->library('upload', $config);
            if ( ! $this->upload->do_upload('image'))
                {

                    $this->session->set_flashdata('msg', $this->upload->display_errors());
                        redirect('dashboard/carousel');
                }
                else
                {
                    $title = $this->input->post('title');
                    $description = $this->input->post('description');
                   $image =  $this->upload->data('file_name');
                   $link =  $this->input->post('link');
                        $data = array(
                            'image'=> $image,
                            'title' => $title,
                            'description'=> $description,
                            'link' => $link,
                            );
                    $insert_query = $this->db->insert('carousel', $data);
                    if($insert_query){
                        $this->session->set_flashdata('msg','Data updated successfully');
                    }else{
                        $this->session->set_flashdata('msg','Something went wrong!');
                    }
                    redirect('dashboard/carousel');
                    
                }
        
    }
    public function update_carousel(){
        $old_photo = $this->input->post('old_photo');
        $photo = $_FILES['new_photo']['name'];
        
        if($photo != ""){
            $photoExt1 = @end(explode('.',$photo));
            $phototest1 = strtolower($photoExt1);
            $new_photo = time().'.'.$phototest1;
            $photo_path = './_assets/upload/carousel/'.$new_photo;
            move_uploaded_file($_FILES['new_photo']['tmp_name'],$photo_path);
        }
        if($photo==''){
            $new_photo = $old_photo;
        }
        
        
        $title = $this->input->post('title');
        $description = $this->input->post('description');
        $link = $this->input->post('link');
        
        $data = array(
        'title' => $title,
        'description' => $description,
        'image'=> $new_photo,
        'link' =>$link
        
        );
        $this->db->where('id',$this->input->post('id'));
        $update_query = $this->db->update('carousel', $data);
        if($update_query){
            $this->session->set_flashdata('msg','Data updated successfully');
        }else{
            $this->session->set_flashdata('msg','Something went wrong!');
        }
        redirect('dashboard/carousel');
    }
    public function delete_carousel($id){
        $this->db->where('id',$id);
        $delete_query = $this->db->delete('carousel');
        
        if($delete_query){
            $this->session->set_flashdata('msg','Data deleted successfully');
        }else{
            $this->session->set_flashdata('msg','Something went wrong!');    
        }
        redirect('dashboard/carousel');
    }
    public function update_top_image()
    {
        $old_photo = $this->input->post('old_photo');
        $photo = $_FILES['new_photo']['name'];
        
        if($photo != ""){
            $photoExt1 = @end(explode('.',$photo));
            $phototest1 = strtolower($photoExt1);
            $new_photo = time().'.'.$phototest1;
            $photo_path = './_assets/upload/top_images/'.$new_photo;
            move_uploaded_file($_FILES['new_photo']['tmp_name'],$photo_path);
        }
        if($photo==''){
            $new_photo = $old_photo;
        }

         $data = array(
        'allpage_top_image'=> $new_photo,
        
        );
        
        $this->db->where('id', 1);
        $update_data = $this->db->update('images', $data);
        
        if($update_data){
            $this->session->set_flashdata('msg','Data Successfully Updated');
        }else{
            $this->session->set_flashdata('msg','Something Went Wrong!');
        }
        redirect('dashboard/administrator');
    }
    public function delete_testimonial($id)
    {
        $this->db->where('id',$id);
        $delete_query = $this->db->delete('testimonials');
        
        if($delete_query){
            $this->session->set_flashdata('msg','Data deleted successfully');
        }else{
            $this->session->set_flashdata('msg','Something went wrong!');    
        }
        redirect('dashboard/manage_testimonials');
    }
    public function addtestimonial()
    {
        $config['upload_path']  = './_assets/upload/person';
        $config['allowed_types'] = 'jpg|jpeg|png|gif';
        $config['max_size']  = 0;

        $this->load->library('upload', $config);
            if ( ! $this->upload->do_upload('image'))
                {

                $this->session->set_flashdata('msg', $this->upload->display_errors());
                redirect('dashboard/manage_testimonials');
                }
                else
                {
                    $name = $this->input->post('name');
                    $position = $this->input->post('position');
                   $image =  $this->upload->data('file_name');
                   $message =  $this->input->post('message');
                        $data = array(
                            'name'=> $name,
                            'position' => $position,
                            'image'=> $image,
                            'message' => $message,
                            );
                    $insert_query = $this->db->insert('testimonials', $data);
                    if($insert_query){
                        $this->session->set_flashdata('msg','Data updated successfully');
                    }else{
                        $this->session->set_flashdata('msg','Something went wrong!');
                    }
                    redirect('dashboard/manage_testimonials');
                    
                }
    }
    public function update_testimonial($id)
    {
        $old_photo = $this->input->post('old_photo');
        $photo = $_FILES['new_photo']['name'];
        
        if($photo != ""){
            $photoExt1 = @end(explode('.',$photo));
            $phototest1 = strtolower($photoExt1);
            $new_photo = time().'.'.$phototest1;
            $photo_path = './_assets/upload/person/'.$new_photo;
            move_uploaded_file($_FILES['new_photo']['tmp_name'],$photo_path);
        }
        if($photo==''){
            $new_photo = $old_photo;
        }
        
        
        $name = $this->input->post('name');
        $position = $this->input->post('position');
        $message = $this->input->post('message');
        
        $data = array(
        'name' => $name,
        'position' => $position,
        'image'=> $new_photo,
        'message' =>$message
        
        );
        $this->db->where('id',$this->input->post('id'));
        $update_query = $this->db->update('testimonials', $data);
        if($update_query){
            $this->session->set_flashdata('msg','Data updated successfully');
        }else{
            $this->session->set_flashdata('msg','Something went wrong!');
        }
        redirect('dashboard/manage_testimonials');
    }
    public function add_inventory()
    {
        $seed_id = $this->input->post('seed');
        $name = $this->input->post('name');
        $email = $this->input->post('email');
        $mobile = $this->input->post('mobile');
        $address = $this->input->post('address');
        $quantity = $this->input->post('quantity');

        $query = $this->db->from('seeds')->where('id',$seed_id)->get()->row();
        $seed_category_id =  $query->category_id;
        $expiry_date = $query->expiry_date;
        date_default_timezone_set("Asia/Calcutta");
        $date = date('Y-m-d');
        $time = date("H:i:s");
        $invoice_number = "invoice@ ".rand(10000000,99999999);
        $inventory_status = $this->input->post('inventory_status');

        $get_quantity_from_seed = $this->db->from('seeds')->where('id',$seed_id)->get()->row();
        $quantityfromseed = $get_quantity_from_seed->quantity;
        if($inventory_status == 1 ){
            $totalquantity =  $quantityfromseed+$quantity;  
        }else{
             if($quantityfromseed < $quantity){
                $this->session->set_flashdata('msg','You can not sell this seed because quantity is less than your input!');
                 redirect('dashboard/seed_inventry');exit;
            }else{
                $totalquantity =  $quantityfromseed-$quantity;
            }
            
        }
        $data1 = array(
            'quantity' => $totalquantity,
        );
        $update_query = $this->db->where('id',$seed_id)->update('seeds',$data1);
        if($update_query){
                $data = array(
                    'seed_category_id' => $seed_category_id,
                    'seed_id' => $seed_id,
                    'date' => $date,
                    'time'=> $time,
                    'expiry_date' => $expiry_date,
                    'name' => $name,
                    'email' => $email,
                    'mobile' => $mobile,
                    'address' => $address,
                    'quantity' => $quantity,
                    'invoice_number' => $invoice_number,
                );

                // print_r($data);exit;

                $insert_query = $this->db->insert('seed_inventry', $data);
                if($insert_query){
                    $this->session->set_flashdata('msg','Data inserted successfully');
                }else{
                    $this->session->set_flashdata('msg','Something went wrong');
                }
        }else{
            $this->session->set_flashdata('msg','Something went wrong');
        }
        
        redirect('dashboard/seed_inventry');
    }

    public function delete_inventory($id)
    {
        $this->db->where('id',$id);
        $delete_query = $this->db->delete('seed_inventry');
        
        if($delete_query){
            $this->session->set_flashdata('msg','Data deleted successfully');
        }else{
            $this->session->set_flashdata('msg','Something went wrong!');    
        }
        redirect('dashboard/seed_inventry');
    }

































    
    // public function about_update(){
    //     $old_photo = $this->input->post('old_photo');
    //     $photo = $_FILES['new_photo']['name'];
        
    //     if($photo != ""){
    //         $photoExt1 = @end(explode('.',$photo));
    //         $phototest1 = strtolower($photoExt1);
    //         $new_photo = time().'.'.$phototest1;
    //         $photo_path = './assets/wp-content/uploads/2020/03/'.$new_photo;
    //         move_uploaded_file($_FILES['new_photo']['tmp_name'],$photo_path);
    //     }
    //     if($photo==''){
    //         $new_photo = $old_photo;
    //     }
        
        
    //     $title = $this->input->post('title');
    //     $description = $this->input->post('description');
    //     $p1 = $this->input->post('p1');
    //     $p2 = $this->input->post('p2');
    //     $p3 = $this->input->post('p3');
    //     $button_h = $this->input->post('button_h');
    //     $button_title = $this->input->post('button_title');
        
    //     $data = array(
    //     'title' => $title,
    //     'description' => $description,
    //     'p1' => $p1,
    //     'p2' =>$p2,
    //     'p3' => $p3,
    //     'button_heading' => $button_h,
    //     'button_title' =>$button_title,
    //     'image'=> $new_photo,
        
    //     );
        
    //     $this->db->where('id', 1);
    //     $update_data = $this->db->update('about', $data);
        
    //     if($update_data){
    //         $this->session->set_flashdata('msg','Data Successfully Updated');
    //         redirect('about');
    //     }else{
    //         $this->session->set_flashdata('msg','Something Went Wrong!');
    //         redirect('about');
    //     };
        
    // }
   
 
    
    
    
    
    
    
    
}