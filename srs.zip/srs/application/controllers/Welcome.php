<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Welcome extends CI_Controller
{

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	 public function __construct()
    {
        parent::__construct();
        $this->load->model('categorymodel', 'cat');
        $this->load->model('UserModel');

        
    }
    
    public function index(){
    	$data['title'] = 'Home';
    	$data['testimonials'] = $this->db->from('testimonials')->get()->result_array();
    	$data['seed_category'] = $this->db->from('seed_category')->get()->result_array();
    	$data['seeds'] = $this->db->from('seeds')->limit(20)->get()->result_array();
    	$data['carousel'] = $this->db->from('carousel')->where('status',1)->get()->result_array();
    	$data['category'] = $this->db->from('category')->get()->result_array();
    	$data['important_links'] = $this->db->from('footer_links')->get()->result_array();
    	$data['settings'] = $this->UserModel->settings();
    	$data['categories'] = $this->cat->category_menu();
    	$this->load->view('website/'.__FUNCTION__,$data);
    }
	public function about(){
		$data['title'] = 'About';
		$data['testimonials'] = $this->db->from('testimonials')->get()->result_array();
		$data['images'] = $this->db->from('images')->get()->result_array();
		$data['category'] = $this->db->from('category')->get()->result_array();
		$data['important_links'] = $this->db->from('footer_links')->get()->result_array();
		$data['settings'] = $this->UserModel->settings();
		$data['categories'] = $this->cat->category_menu();
		$this->load->view('website/'.__FUNCTION__, $data);
	}	
	public function contact(){
		$data['title'] = 'Contact';
		$data['images'] = $this->db->from('images')->get()->result_array();
		$data['category'] = $this->db->from('category')->get()->result_array();
		$data['important_links'] = $this->db->from('footer_links')->get()->result_array();
		$data['settings'] = $this->UserModel->settings();
		$data['categories'] = $this->cat->category_menu();
		$this->load->view('website/'.__FUNCTION__, $data);
	}
	public function shop($id=null){
		$data['title'] = 'Shop';
		if($id == null){
			$data['seeds'] = $this->db->from('seeds')->get()->result_array();
		}else{
			$data['seeds'] = $this->db->from('seeds')->where('category_id',$id)->get()->result_array();
		}
		$data['seed_category'] = $this->db->from('seed_category')->get()->result_array();
    	
		$data['images'] = $this->db->from('images')->get()->result_array();
		$data['category'] = $this->db->from('category')->get()->result_array();
		$data['important_links'] = $this->db->from('footer_links')->get()->result_array();
		$data['settings'] = $this->UserModel->settings();
		$data['categories'] = $this->cat->category_menu();
		$this->load->view('website/'.__FUNCTION__, $data);
	}
	public function page($id){
		
		$data['pages'] = $this->db->from('pages')->where('p_id',$id)->get()->result_array();
		if($data['pages']){
			$data['images'] = $this->db->from('images')->get()->result_array();
			$data['important_links'] = $this->db->from('footer_links')->get()->result_array();
			$data['category'] = $this->db->from('category')->get()->result_array();
			$title = $this->db->select('*')->where('p_id',$id)->from('pages')->get()->row();
			$data['title'] = $title->p_name;
			$data['settings'] = $this->UserModel->settings();
			$data['categories'] = $this->cat->category_menu();
			$this->load->view('website/'.__FUNCTION__,$data);
		}else{
			echo "<script>alert('page not available');</script>";
			redirect('/');
		}
		
	}
	
	
	

}
