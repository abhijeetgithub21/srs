<?php
defined('BASEPATH') or exit('No direct script access allowed');

class AdminLogin extends CI_Controller
{
    public function __construct() {
        parent::__construct();
        $this->load->helper(array('form', 'url'));
        $this->load->library(['form_validation','session']);
        $this->load->model('UserModel');
        $this->load->database();
    }

    public function index()
    {
        if($this->session->userdata('id')){
            $id = $this->session->userdata('id');
            $query = $this->db->from('users')->where('id',$id)->get()->row();
            if($query->access == 1){
                redirect('admin');
            }else{
                $this->load->view('admin_login');
            }
            
        }else{
            // $data['settings'] = $this->UserModel->settings();
            $this->load->view('admin_login');
        }
    }

    public function login() {

            $username = $this->input->post('email');
            $password = $this->input->post('password');
            $user = $this->db->get_where('users',['email' => $username,'password'=>$password,'status'=>1,'access'=>1])->row();
            
            if(!$user) {
                $this->session->set_flashdata('login_error', 'Please check your email or password and try again.', 300);
                redirect('AdminLogin');
            }else{
                if($password !== $user->password) {
                $this->session->set_flashdata('login_error', 'Please check your email or password and try again.', 300);
                redirect('AdminLogin');
                }else{
                     $data = array(
                    'id' => $user->id,
                    'name' => $user->name,
                    'email' => $email,
                    'mobile' => $mobile,
                    'login' => 'a',
                    );
                     $this->session->set_userdata($data);
                      redirect('Dashboard',$data);
                }

            }
           
    }

    public function logout(){
        $this->session->sess_destroy();
        redirect('/');
    }

}
