<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Gardner extends CI_Controller
{
    public function __construct() {
        parent::__construct();
        $this->load->model('UserModel');
       if($this->session->userdata('login') != "c"){
            redirect('gardnerlogin');
        }
    }
    
    
    public function index(){
        $id = $_SESSION['id'];
        $data['users'] = $this->db->from('users')->where('id',$id)->get()->result_array();
        $data['page_title'] = 'Gardner Dashboard';
        $this->load->view('gardner/dashboard',$data);
    }

    public function dashboard(){
        $id = $_SESSION['id'];
        $data['users'] = $this->db->from('users')->where('id',$id)->get()->result_array();
        $data['page_title'] = 'Gardner Dashboard';
        $this->load->view('gardner/dashboard',$data);
    }

    public function setting()
    {
        $id = $_SESSION['id'];
        $data['users'] = $this->db->from('users')->where('id',$id)->get()->result_array();
        $data['page_title'] = 'Employee Settings';
        $this->load->view('gardner/'.__FUNCTION__,$data);
    }
    public function update_detail($id){
        $data['name'] = $this->input->post('name');
        $data['email'] = $this->input->post('email');
        $data['mobile'] = $this->input->post('mobile');
        $data['address'] = $this->input->post('address');

        $this->db->where('id',$id);
        $update_query = $this->db->update('users',$data);
        if($update_query){
            $this->session->set_flashdata('msg','Data Successfully Updated');   
            }else{
                $this->session->set_flashdata('msg','Something went wrong'); 
            }
            redirect('gardner/setting');
    }
    public function change_pass($id)
    {

        $num = $this->db->select('*')->where('id',$id)->get('users')->num_rows();
        if($num > 0){
            $old_pass = $this->input->post('old_pass');
            $query = $this->db->from('users')->where('id',$id)->get()->row();
            // echo $old_pass.$query->password;exit;
            if($query->password === $old_pass){
                $new_pass = $this->input->post('new_pass');
                $c_new_pass = $this->input->post('c_new_pass');
                if($new_pass == $c_new_pass){
                    $data['password'] = $new_pass;
                    $udpate_query = $this->db->where('id',$id)->update('users',$data);
                    if($udpate_query){
                        $this->session->set_flashdata("msg","Password Successfully Changed");
                    }else{
                        $this->session->set_flashdata("msg","Passowrd didn't change");
                    }
                }else{
                     $this->session->set_flashdata("msg","new passwords doesn't match");
                }
            }else{
                $this->session->set_flashdata("msg","Current password doesn't match");
            }
        }else{
            $this->session->set_flashdata('msg','Something went wrong');
        }
        redirect('gardner/setting');
    }


}
