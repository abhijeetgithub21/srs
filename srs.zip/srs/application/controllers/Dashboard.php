<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Dashboard extends CI_Controller
{

    function __construct(){
        parent::__construct();
        $this->load->database();
        $this->load->model('Footer');
        $this->load->model('About');
        $this->load->model('UserModel');
        $this->load->model('Services');
        $this->load->model('Carousel');
        if($this->session->userdata('login') != "a"){
            redirect('AdminLogin');
        }
    }
    
    public function index()
    {   
        $data['settings'] = $this->UserModel->settings();
        // $data['get_all_footer_details'] = $this->Footer->get_all_footer_details();
        $data['page_title'] = 'Admin Dashboard';
        $this->load->view('admin/elements/header',$data);
        $this->load->view('admin/elements/sidebar');
        $this->load->view('admin/dashboard');
        $this->load->view('admin/elements/footer');
    }
    public function gardners(){
    	$data['gardners'] = $this->db->from('users')->where(array('status'=>1,'access'=>3))->get()->result_array();
    	$data['settings'] = $this->UserModel->settings();
        $data['page_title'] = 'Manage Gardners';
        $this->load->view('admin/elements/header',$data);
        $this->load->view('admin/elements/sidebar');
        $this->load->view('admin/manage_gardners');
        $this->load->view('admin/elements/footer');
    }
    public function employees(){
    	$data['employees'] = $this->db->from('users')->where(array('status'=>1,'access'=>2))->get()->result_array();
    	$data['settings'] = $this->UserModel->settings();
        $data['page_title'] = 'Manage Employees';
        $this->load->view('admin/elements/header',$data);
        $this->load->view('admin/elements/sidebar');
        $this->load->view('admin/manage_employees');
        $this->load->view('admin/elements/footer');
    }
    public function administrator(){
        $data['images'] = $this->db->from('images')->where('id',1)->get()->result_array();
    	$data['settings'] = $this->db->from('settings')->get()->result_array();
    	$data['users'] = $this->db->from('users')->where(array('status'=>1,'access'=>1))->get()->result_array();
    	$data['settings'] = $this->UserModel->settings();
        $data['page_title'] = 'Administrator Settings';
        $this->load->view('admin/elements/header',$data);
        $this->load->view('admin/elements/sidebar');
        $this->load->view('admin/manage_administrator');
        $this->load->view('admin/elements/footer');
    }
    public function edit_gardner($id){
    	$data['settings'] = $this->db->from('settings')->get()->result_array();
    	$data['users'] = $this->db->from('users')->where(array('status'=>1,'access'=>3))->get()->result_array();
    	$data['settings'] = $this->UserModel->settings();
        $data['page_title'] = 'Edit Gardners';
        $this->load->view('admin/elements/header',$data);
        $this->load->view('admin/elements/sidebar');
        $this->load->view('admin/'.__FUNCTION__);
        $this->load->view('admin/elements/footer');
    }
    public function edit_employee($id){
		$data['settings'] = $this->db->from('settings')->get()->result_array();
    	$data['users'] = $this->db->from('users')->where(array('status'=>1,'access'=>2))->get()->result_array();
    	$data['settings'] = $this->UserModel->settings();
        $data['page_title'] = 'Edit Employees';
        $this->load->view('admin/elements/header',$data);
        $this->load->view('admin/elements/sidebar');
        $this->load->view('admin/'.__FUNCTION__);
        $this->load->view('admin/elements/footer');
    }
     public function manage_page(){
     	$data['pages'] = $this->db->from('pages')->get()->result_array();
    	$data['settings'] = $this->UserModel->settings();
        $data['page_title'] = 'Manage Page';
        $this->load->view('admin/elements/header',$data);
        $this->load->view('admin/elements/sidebar');
        $this->load->view('admin/'.__FUNCTION__);
        $this->load->view('admin/elements/footer');
    }
     public function edit_page($id){
     	$data['pages'] = $this->db->from('pages')->get()->result_array();
    	$data['settings'] = $this->UserModel->settings();
        $data['page_title'] = 'Edit Page';
        $this->load->view('admin/elements/header',$data);
        $this->load->view('admin/elements/sidebar');
        $this->load->view('admin/'.__FUNCTION__);
        $this->load->view('admin/elements/footer');
    }
    public function manage_seed_category(){
    	$data['seed_category'] = $this->db->from('seed_category')->get()->result_array();
    	$data['settings'] = $this->db->from('settings')->get()->result_array();
    	$data['settings'] = $this->UserModel->settings();
        $data['page_title'] = 'Seed Category';
        $this->load->view('admin/elements/header',$data);
        $this->load->view('admin/elements/sidebar');
        $this->load->view('admin/'.__FUNCTION__);
        $this->load->view('admin/elements/footer');
    }
     public function manage_seeds(){
     	$data['seed_category'] = $this->db->from('seed_category')->get()->result_array();
     	$data['seeds'] = $this->db->from('seeds')->get()->result_array();
    	$data['settings'] = $this->db->from('settings')->get()->result_array();
    	$data['settings'] = $this->UserModel->settings();
        $data['page_title'] = 'Seeds';
        $this->load->view('admin/elements/header',$data);
        $this->load->view('admin/elements/sidebar');
        $this->load->view('admin/'.__FUNCTION__);
        $this->load->view('admin/elements/footer');
    }
    public function edit_seed($id){
        $data['seed_category'] = $this->db->from('seed_category')->get()->result_array();
        $data['seeds'] = $this->db->from('seeds')->where('id',$id)->get()->result_array();
        $data['settings'] = $this->db->from('settings')->get()->result_array();
        $data['settings'] = $this->UserModel->settings();
        $data['page_title'] = 'Seeds';
        $this->load->view('admin/elements/header',$data);
        $this->load->view('admin/elements/sidebar');
        $this->load->view('admin/'.__FUNCTION__);
        $this->load->view('admin/elements/footer');
    }
    public function edit_seed_category($id)
    {
        $data['seed_category'] = $this->db->from('seed_category')->where('id',$id)->get()->result_array();
        $data['settings'] = $this->db->from('settings')->get()->result_array();
        $data['settings'] = $this->UserModel->settings();
        $data['page_title'] = 'Edit Seed Category';
        $this->load->view('admin/elements/header',$data);
        $this->load->view('admin/elements/sidebar');
        $this->load->view('admin/'.__FUNCTION__);
        $this->load->view('admin/elements/footer');
    }
    public function seed_inventry(){
        $data['seed_inventry'] = $this->db->from('seed_inventry')->get()->result_array();
        $data['seed_category'] = $this->db->from('seed_category')->get()->result_array();
        $data['seeds'] = $this->db->from('seeds')->get()->result_array();
        $data['settings'] = $this->db->from('settings')->get()->result_array();
        $data['settings'] = $this->UserModel->settings();
        $data['page_title'] = 'Seed Inventry';
        $this->load->view('admin/elements/header',$data);
        $this->load->view('admin/elements/sidebar');
        $this->load->view('admin/'.__FUNCTION__);
        $this->load->view('admin/elements/footer');
    }
    public function carousel()
    {
        $data['carousel'] = $this->db->from('carousel')->get()->result_array();
        $data['settings'] = $this->UserModel->settings();
        $data['settings'] = $this->db->from('settings')->get()->result_array();
        $data['page_title'] = 'Manage Carousel';
        $this->load->view('admin/elements/header',$data);
        $this->load->view('admin/elements/sidebar');
        $this->load->view('admin/manage_carousel');
        $this->load->view('admin/elements/footer');
    }
    public function carousel_edit($id){
        $data['carousel'] = $this->db->from('carousel')->where('id',$id)->get()->result_array();
        $data['settings'] = $this->UserModel->settings();
        $data['settings'] = $this->db->from('settings')->get()->result_array();
        $data['page_title'] = 'Manage Carousel';
        $this->load->view('admin/elements/header',$data);
        $this->load->view('admin/elements/sidebar');
        $this->load->view('admin/edit_carousel');
        $this->load->view('admin/elements/footer');
    }
    public function manage_testimonials()
    {
        $data['testimonial'] = $this->db->from('testimonials')->get()->result_array();
        $data['settings'] = $this->db->from('settings')->get()->result_array();
        $data['settings'] = $this->UserModel->settings();
        $data['page_title'] = 'Manage Testmonials';
        $this->load->view('admin/elements/header',$data);
        $this->load->view('admin/elements/sidebar');
        $this->load->view('admin/'.__FUNCTION__);
        $this->load->view('admin/elements/footer');
    }
    public function testimonial_edit($id)
    {
       $data['testimonial'] = $this->db->from('testimonials')->where('id',$id)->get()->result_array();
        $data['settings'] = $this->UserModel->settings();
        $data['settings'] = $this->db->from('settings')->get()->result_array();
        $data['page_title'] = 'Manage Carousel';
        $this->load->view('admin/elements/header',$data);
        $this->load->view('admin/elements/sidebar');
        $this->load->view('admin/'.__FUNCTION__);
        $this->load->view('admin/elements/footer');
    }





















	
	
	
	
	
	
	
	
	
	
	
    
    
    

}
