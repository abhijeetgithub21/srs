 <!-- partial:partials/_navbar.html -->
 <?php foreach($users as $row){?>
      <nav class="navbar default-layout-navbar col-lg-12 col-12 p-0 fixed-top d-flex flex-row">
        <div class="text-center navbar-brand-wrapper d-flex align-items-center justify-content-center">
          <a class="navbar-brand brand-logo" href="<?= base_url('employee/dashboard'); ?>">
              <!--<img src="<?= base_url(); ?>assets/wp-content/uploads/2020/05/<?= $row['logo']; ?>" alt="logo" />-->
              <h3 style="font-weight:bold;"><?= $row['name']; ?></h3>
              </a>
          
          <a class="navbar-brand brand-logo-mini" href="<?= base_url('employee/dashboard'); ?>"><img src="<?= base_url(); ?>assets/wp-content/uploads/2020/05/" alt="logo" /></a>
          
        </div>
        <div class="navbar-menu-wrapper d-flex align-items-stretch">
          <button class="navbar-toggler navbar-toggler align-self-center" type="button" data-toggle="minimize">
            <span class="mdi mdi-menu"></span>
          </button>
          <div class="search-field d-none d-md-block">
            <form class="d-flex align-items-center h-100" action="#">
              <div class="input-group">
                <div class="input-group-prepend bg-transparent">
                  <i class="input-group-text border-0 mdi mdi-magnify"></i>
                </div>
                <input type="text" class="form-control bg-transparent border-0" placeholder="Search projects">
              </div>
            </form>
          </div>
          <ul class="navbar-nav navbar-nav-right">
            <li class="nav-item nav-profile dropdown">
              <a class="nav-link dropdown-toggle" id="profileDropdown" href="#" data-bs-toggle="dropdown" aria-expanded="false">
                <div class="nav-profile-img">
                  <!--<img src="<?= base_url(); ?>admin_assets/images/faces/face1.jpg" alt="image">-->
                  <!--<span class="availability-status online"></span>-->
                </div>
                <div class="nav-profile-text">
                  <p class="mb-1 text-black">Employee</p>
                </div>
              </a>
              <div class="dropdown-menu navbar-dropdown" aria-labelledby="profileDropdown">
                                <a class="dropdown-item" href="<?= base_url('employee/setting'); ?>">
                  <i class="mdi mdi-settings me-2 text-primary"></i> Setting </a>
                <a class="dropdown-item" href="<?= base_url('employeelogin/logout'); ?>">
                  <i class="mdi mdi-logout me-2 text-primary"></i> Signout </a>
              </div>
            </li>
            <li class="nav-item d-none d-lg-block full-screen-link">
              <a class="nav-link">
                <i class="mdi mdi-fullscreen" id="fullscreen-button"></i>
              </a>
            </li>
          
            
            
            <li class="nav-item nav-settings d-none d-lg-block">
              <a class="nav-link" href="#">
                <i class="mdi mdi-format-line-spacing"></i>
              </a>
            </li>
          </ul>
          <button class="navbar-toggler navbar-toggler-right d-lg-none align-self-center" type="button" data-toggle="offcanvas">
            <span class="mdi mdi-menu"></span>
          </button>
        </div>
      </nav>
      <!-- partial -->
      <div class="container-fluid page-body-wrapper">
        <!-- partial:partials/_sidebar.html -->
        <nav class="sidebar sidebar-offcanvas" id="sidebar">
          <ul class="nav">
            <li class="nav-item nav-profile">
              <a href="#" class="nav-link">
                <div class="nav-profile-image">
                  <!--<img src="<?= base_url(); ?>admin_assets/images/faces/face1.jpg" alt="profile">-->
                  <span class="login-status online"></span>
                  <!--change to offline or busy as needed-->
                </div>
                <div class="nav-profile-text d-flex flex-column">
                  <span class="font-weight-bold mb-2"><?= $row['name']; ?></span>
                  <!--<span class="text-secondary text-small">Project Manager</span>-->
                </div>
                <i class="mdi mdi-bookmark-check text-success nav-profile-badge"></i>
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="<?= base_url('employee');?>">
                <span class="menu-title">Dashboard</span>
                <i class="mdi mdi-home menu-icon"></i>
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="<?= base_url('employee/setting');?>">
                <span class="menu-title">Settings</span>
                <i class="mdi mdi-settings menu-icon"></i>
              </a>
            </li>
             <li class="nav-item">
              <a class="nav-link" href="<?= base_url('employee/seed_inventry');?>">
                <span class="menu-title">Seed Inventry</span>
                <i class="mdi mdi-format-list-bulleted menu-icon"></i>
              </a>
            </li>
             <li class="nav-item">
              <a class="nav-link" data-bs-toggle="collapse" href="#general-pages" aria-expanded="false" aria-controls="general-pages">
                <span class="menu-title">Manage Seed</span>
                <i class="menu-arrow"></i>
                <i class="mdi mdi-medical-bag menu-icon"></i>
              </a>
              <div class="collapse" id="general-pages">
                <ul class="nav flex-column sub-menu">
                  <li class="nav-item"> <a class="nav-link" href="<?= base_url('employee/manage_seed_category');?>"> Seed Category  </a></li>
                  <li class="nav-item"> <a class="nav-link" href="<?= base_url('employee/manage_seeds');?>"> Seeds  </a></li>
                </ul>
              </div>
            </li>
            
            <!-- <li class="nav-item">
              <a class="nav-link" data-bs-toggle="collapse" href="#general-pages" aria-expanded="false" aria-controls="general-pages">
                <span class="menu-title">Users</span>
                <i class="menu-arrow"></i>
                <i class="mdi mdi-medical-bag menu-icon"></i>
              </a>
              <div class="collapse" id="general-pages">
                <ul class="nav flex-column sub-menu">
                  <li class="nav-item"> <a class="nav-link" href="<?=base_url('dashboard/gardners');?>"> Gardners </a></li>
                  <li class="nav-item"> <a class="nav-link" href="<?=base_url('dashboard/employees');?>"> Employees </a></li>
                  <li class="nav-item"> <a class="nav-link" href="<?=base_url('dashboard/administrator');?>"> Administrator Settings </a></li>
                </ul>
              </div>
            </li> -->
            
           <!--  <li class="nav-item">
              <a class="nav-link" href="<?= base_url('dashboard/manage_site');?>">
                <span class="menu-title">Manage Site</span>
                <i class="mdi mdi-format-list-bulleted menu-icon"></i>
              </a>
            </li>
             <li class="nav-item">
              <a class="nav-link" href="<?= base_url();?>services_table">
                <span class="menu-title">Services</span>
                <i class="mdi mdi-format-list-bulleted menu-icon"></i>
              </a>
            </li>
             <li class="nav-item">
              <a class="nav-link" href="<?= base_url();?>packages">
                <span class="menu-title">Packages</span>
                <i class="mdi mdi-format-list-bulleted menu-icon"></i>
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="<?= base_url();?>orders">
                <span class="menu-title">Orders</span>
                <i class="mdi mdi-format-list-bulleted menu-icon"></i>
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="<?= base_url();?>manage_carousel">
                <span class="menu-title">Manage Carousel</span>
                <i class="mdi mdi-format-list-bulleted menu-icon"></i>
              </a>
            </li>
             <li class="nav-item">
              <a class="nav-link" href="<?= base_url();?>manage_gallery">
                <span class="menu-title">Manage Gallery</span>
                <i class="mdi mdi-format-list-bulleted menu-icon"></i>
              </a>
            </li>
             <li class="nav-item">
              <a class="nav-link" href="<?= base_url();?>manage_feedback">
                <span class="menu-title">Feedbacks</span>
                <i class="mdi mdi-format-list-bulleted menu-icon"></i>
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link" data-bs-toggle="collapse" href="#general-pages" aria-expanded="false" aria-controls="general-pages">
                <span class="menu-title">Footer Settings</span>
                <i class="menu-arrow"></i>
                <i class="mdi mdi-medical-bag menu-icon"></i>
              </a>
              <div class="collapse" id="general-pages">
                  <?php foreach($get_all_footer_details as $row){?>
                <ul class="nav flex-column sub-menu">
                  <li class="nav-item"> <a class="nav-link" href="<?= base_url();?>main_footer"> Main </a></li>
                  <li class="nav-item"> <a class="nav-link" href="<?= base_url();?>footer1"> <?= $row['heading1']; ?> </a></li>
                  <li class="nav-item"> <a class="nav-link" href="<?= base_url();?>footer2"> <?= $row['heading2']; ?> </a></li>
                </ul>
                <?php } ?>
              </div>
            </li>
            
            <li class="nav-item">
              <a class="nav-link" data-bs-toggle="collapse" href="#general-pages" aria-expanded="false" aria-controls="general-pages">
                <span class="menu-title">Pages</span>
                <i class="menu-arrow"></i>
                <i class="mdi mdi-medical-bag menu-icon"></i>
              </a>
              <div class="collapse" id="general-pages">
                <ul class="nav flex-column sub-menu">
                  <li class="nav-item"> <a class="nav-link" href="<?=base_url();?>about"> About </a></li>
                  
                  <li class="nav-item"> <a class="nav-link" href="<?=base_url();?>testimonials"> Testimonials </a></li>
                  <li class="nav-item"> <a class="nav-link" href="<?=base_url();?>contact"> Contact </a></li>
                  <li class="nav-item"> <a class="nav-link" href="<?=base_url();?>manage_tarot_reading"> Tarot Reading  </a></li>
                  <li class="nav-item"> <a class="nav-link" href="<?=base_url();?>manage_healing"> Healing  </a></li>
                  <li class="nav-item"> <a class="nav-link" href="<?=base_url();?>manage_reiki"> Reiki  </a></li>
                  <li class="nav-item"> <a class="nav-link" href="<?=base_url();?>manage_vastu"> Vastu  </a></li>
                  <li class="nav-item"> <a class="nav-link" href="<?=base_url();?>manage_numerology"> Numerology  </a></li>
          
                </ul>
              </div>
            </li> -->
            
            
          </ul>
        </nav>
        <?php }?>