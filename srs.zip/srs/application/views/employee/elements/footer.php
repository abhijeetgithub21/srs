          <!-- partial:partials/_footer.html -->
          <footer class="footer">
            <div class="container-fluid d-flex justify-content-between">
              <span class="text-muted d-block text-center text-sm-start d-sm-inline-block">Copyright © theastrologyvision.com <?= date('Y');?></span>
              <!--<span class="float-none float-sm-end mt-1 mt-sm-0 text-end"> Free <a href="https://www.bootstrapdash.com/bootstrap-admin-template/" target="_blank">Bootstrap admin template</a> from Bootstrapdash.com</span>-->
            </div>
          </footer>
          <!-- partial -->
        </div>
        <!-- main-panel ends -->
      </div>
      <!-- page-body-wrapper ends -->
    </div>
    <!-- container-scroller -->
    <!-- plugins:js -->
    <script type="text/javascript">
      $("#success-alert").fadeTo(2000, 500).slideUp(500, function(){
    $("#success-alert").slideUp(500);
});
    </script>
    <script src="<?= base_url(); ?>_admin_assets/vendors/js/vendor.bundle.base.js"></script>
    <!-- endinject -->
    <!-- Plugin js for this page -->
    <script src="<?= base_url(); ?>_admin_assets/vendors/chart.js/Chart.min.js"></script>
    <script src="<?= base_url(); ?>_admin_assets/js/jquery.cookie.js" type="text/javascript"></script>
    <!-- End plugin js for this page -->
    <!-- inject:js -->
    <script src="<?= base_url(); ?>_admin_assets/js/off-canvas.js"></script>
    <script src="<?= base_url(); ?>_admin_assets/js/hoverable-collapse.js"></script>
    <script src="<?= base_url(); ?>_admin_assets/js/misc.js"></script>
    <!-- endinject -->
    <!-- Custom js for this page -->
    <script src="<?= base_url(); ?>_admin_assets/js/dashboard.js"></script>
    <script src="<?= base_url(); ?>_admin_assets/js/todolist.js"></script>
    <script type="text/javascript" src="//cdn.datatables.net/1.11.4/js/jquery.dataTables.min.js"></script>
    <script type="text/javascript">
      $(document).ready( function () {
    $('#myTable').DataTable();
        } );
    </script>
    <!-- End custom js for this page -->

  </body>
</html>