<?php 
include_once('elements/header.php');
include_once('elements/sidebar.php');
?>
        <!-- partial -->
        <div class="main-panel">
          <div class="content-wrapper">
            <div class="page-header">
              <h3 class="page-title">  Manage Seeds </h3>
              <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                  <li class="breadcrumb-item"><a href="#">Manage Seeds</a></li>
                  <li class="breadcrumb-item active" aria-current="page">Seed</li>
                </ol>
              </nav>
            </div>
            
            
            <div class="row"  >
              <div class="col-md-6 grid-margin stretch-card" id="add_seed" style="display:none;" >
                <div class="card">
                  <div class="card-body">
                      <a class="btn btn-danger" onclick="allSeeds()" style="float:right;">All Seeds</a>
                    <h4 class="card-title">Add Seed</h4>
                    <!--<p class="card-description"> Basic form layout </p>-->
                   <form class="forms-sample" action="<?= base_url('employee/add_seed'); ?>" method="POST" enctype="multipart/form-data">
                        <div class="form-group">
                        <label for="name">Name </label>
                        <input type="text" class="form-control" id="name" name="name"  required>
                      </div>
                      <div class="form-group">
                        <label for="category">Category Name </label>
                       <select class="form-control" name="category" id="category">
                        <?php foreach($seed_category as $row){ ?>
                        <option value="<?= $row['id']; ?>"><?= $row['name']; ?></option>
                      <?php } ?>
                       </select>
                      </div>
                       <div class="form-group">
                        <label for="image">Image  </label>
                        <input type="file" class="form-control" id="image" name="image">
                      </div>
                       <div class="form-group">
                        <label for="expiry_date">Expiry Date </label>
                        <input type="date" class="form-control" id="expiry_date" name="expiry_date"  required>
                      </div>
                       <div class="form-group">
                        <label for="quantity">Quantiy (in Kg) </label>
                        <input type="text" class="form-control" id="quantity" name="quantity"  required>
                      </div>
                     
                       <button type="submit" class="btn btn-gradient-primary me-2" name="submit" style="float:right;">Submit</button>
                      <!--<button class="btn btn-light">Cancel</button>-->
                    </form>
                    
                  </div>
                </div>
              </div>
             
           
           <div class="col-lg-12 grid-margin stretch-card" id="all_seeds">
                <div class="card">
                  <div class="card-body">
                       <?php 
                        if ($this->session->flashdata('msg') != ''): ?>
                        <div class="alert alert-success close" role="alert">
                              <?php echo $this->session->flashdata('msg');  ?>
                            </div>
                            <?php endif; ?>
                    <a class="btn btn-danger" onclick="addSeed()">Add Seed</a>
                    <div class="table-responsive pt-3">
                    <table class="table table-bordered" id="myTable">
                      <thead>
                        <tr>
                          <th> # </th>
                          <th>Name</th>
                          <th>Category</th>
                          <th>Expiry Date</th>
                          <th>Quantity (in Kg)</th>
                          <th>Image</th>
                          <th>Action </th>
                        </tr>
                      </thead>
                      <tbody>
                          <?php $i = 1; foreach($seeds as $row){ ?>
                        <tr>
                          <td> <?php echo $i++ ?> </td>
                          <td> <?= $row['name']; ?> </td>
                          <td> 
                              <?php foreach($seed_category as $c){
                                if($c['id'] == $row['category_id'] ){
                                  echo $c['name'];
                                }
                              }?>

                           </td>
                          <td> <?= $row['expiry_date']; ?> </td>
                          <td> <?= $row['quantity']; ?> </td>
                          <td> <img  src="<?= base_url('_assets/upload/seeds/'); ?><?= $row['image']; ?>" alt="image not found"> </td>
                          <td>
                            <a href="<?= base_url('employee/edit_seed'); ?>/<?php echo $row['id'] ?>" class="btn btn-sm btn-outline-primary"><i class="fas fa-edit"></i> Edit</a>
                              <a href="<?= base_url('employee/delete_seed'); ?>/<?php echo $row['id'] ?>" class="btn btn-sm btn-outline-danger"><i class="fas fa-trash-alt"></i> Delete</a>
                          </td>
                        </tr>
                        <?php } ?>
                      </tbody>
                    </table>
                    </div>
                  </div>
                </div>
              </div>
           <script>
function addSeed() {
  document.getElementById("add_seed").style.display = "block";
  document.getElementById("all_seeds").style.display = "none";
}
function allSeeds(){
    document.getElementById("add_seed").style.display = "none";
    document.getElementById("all_seeds").style.display = "block";
}
</script>


            <?php 
include_once('elements/footer.php');
?>