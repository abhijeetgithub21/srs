
        <!-- partial -->
        <div class="main-panel">
          <div class="content-wrapper">
            <div class="page-header">
              <h3 class="page-title">  Manage Adminstrator </h3>
              <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                  <li class="breadcrumb-item"><a href="#">Manage Adminstrator</a></li>
                  <li class="breadcrumb-item active" aria-current="page">Users</li>
                </ol>
              </nav>
            </div>
       <?php if(!empty($this->session->flashdata('msg'))) {?> 
    <div class="alert alert-success">
       <?php echo $this->session->flashdata('msg'); ?>
    </div>
<?php } ?>
 <?php foreach($settings as $row){?>           
           
           <div class="row">
              <div class="col-md-6 grid-margin stretch-card">
                <div class="card">
                  <div class="card-body">
                    <h4 class="card-title"> Website Details</h4>
                    <!--<p class="card-description"> Basic form layout </p>-->
                    <form class="forms-sample" action="<?= base_url('Form/manage_site_function'); ?>" method="POST" enctype="multipart/form-data">
                      <div class="form-group">
                        <label for="website_name">Website Name</label>
                        <input type="text" class="form-control" id="website_name" name="website_name" value="<?= $row['name']; ?>" required>
                      </div>
                      <div class="form-group">
                        <label for="website_email">Email Id </label>
                        <input type="email" class="form-control" id="website_email" name="website_email" value="<?= $row['email']; ?>" required>
                      </div>
                      
                       <div class="form-group">
                        <label for="mobile">Mobile Number </label>
                        <input type="number" class="form-control" id="mobile" name="mobile" value="<?= $row['mobile_number']; ?>" required>
                      </div>
                       <div class="form-group">
                        <label for="address">Address</label>
                        <textarea class="form-control" id="address" name="address" rows="3"><?= $row['address']; ?></textarea>
                      </div>
                  </div>
                </div>
              </div>
              <?php } ?>  
              <?php foreach($users as $u){?>
              <div class="col-md-6 grid-margin stretch-card">
                <div class="card">
                  <div class="card-body">
                    <h4 class="card-title"> Admin Details</h4>
                     <div class="form-control">
                      <div class="form-group">
                        <label for="admin_name">Name</label>
                        <input type="text" class="form-control" id="admin_name" name="admin_name" value="<?= $u['name']; ?>" required>
                      </div> 
                      <div class="form-group">
                        <label for="admin_email">Email Or Username</label>
                        <input type="email" class="form-control" id="admin_email" name="admin_email" value="<?= $u['email']; ?>" required>
                      </div> 
                      <div class="form-group">
                        <label for="password">Password</label>
                        <input type="text" class="form-control" id="password" name="password" value="<?= $u['password']; ?>" >
                      </div>
                      <div class="form-group">
                        <label for="admin_mobile">Mobile</label>
                        <input type="text" class="form-control" id="admin_mobile" name="admin_mobile" value="<?= $u['mobile']; ?>" >
                      </div>                   
                      <button type="submit" class="btn btn-gradient-primary me-2" style="float:right;">Update</button>
                      <!--<button class="btn btn-light">Cancel</button>-->
                    </form>
                  </div>
                </div>
              </div>
            </div>
            <?php } ?>
           <?php foreach($settings as $row){?>
             <div class="col-md-6 grid-margin stretch-card">
                <div class="card">
                  <div class="card-body">
                    <h4 class="card-title"> Top Bar Title </h4>
                     <div class="form-control">
                      <form method="post" action="<?= base_url('Form/top_bar_title')?>"> 
                      <div class="form-group">
                       <textarea class="form-control" name="top_bar_title" rows="4"><?= $row['top_bar_title']; ?></textarea>     
                       </div>           
                      <button type="submit" class="btn btn-gradient-primary me-2" style="float:right;">Update</button>
                      <!--<button class="btn btn-light">Cancel</button>-->
                    </form>
                  </div>
                </div>
              </div>
            </div>
             <div class="col-md-6 grid-margin stretch-card">
                <div class="card">
                  <div class="card-body">
                    <h4 class="card-title"> Google Map Embed code </h4>
                     <div class="form-control">
                      <form method="post" action="<?= base_url('Form/google_map')?>"> 
                      <div class="form-group">
                       <textarea class="form-control" name="google_map" rows="10"><?= $row['google_map']; ?></textarea>     
                       </div>           
                      <button type="submit" class="btn btn-gradient-primary me-2" style="float:right;">Update</button>
                      <!--<button class="btn btn-light">Cancel</button>-->
                    </form>
                  </div>
                </div>
              </div>
            </div>
             <div class="row">
            <div class="col-md-6 grid-margin stretch-card">
                <div class="card">
                  <div class="card-body">
                    <h4 class="card-title"> Social Links</h4>
                     <div class="form-control">
                      <form method="post" action="<?= base_url('Form/update_links')?>">
                      <div class="form-group">
                        <label for="facebook">Facebook</label>
                        <input type="text" class="form-control" id="facebook" name="facebook" value="<?= $row['facebook']; ?>" required>
                      </div> 
                      <div class="form-group">
                        <label for="instagram">Instragram</label>
                        <input type="text" class="form-control" id="instagram" name="instagram" value="<?= $row['instagram']; ?>" required>
                      </div> 
                      <div class="form-group">
                        <label for="twiter">Twiter</label>
                        <input type="text" class="form-control" id="twiter" name="twiter" value="<?= $row['twiter']; ?>" required>
                      </div>                   
                      <button type="submit" class="btn btn-gradient-primary me-2" style="float:right;">Update</button>
                      <!--<button class="btn btn-light">Cancel</button>-->
                    </form>
                  </div>
                </div>
              </div>
            </div>
            <?php } ?>
            <?php foreach($images as $i){?>
             <div class="col-md-6 grid-margin stretch-card">
                <div class="card">
                  <div class="card-body">
                    <h4 class="card-title"> Top Image</h4>
                     <div class="form-control">
                      <form method="post" action="<?= base_url('Form/update_top_image');?>" enctype="multipart/form-data">
                                 
                      <div class="form-group">
                        <h3>Current Logo</h3>
                        <img src="<?php echo base_url(); ?>_assets/upload/top_images/<?php echo $i['allpage_top_image']; ?>" height="44%" width="55%" />
                        <input type="hidden" name="old_photo" value="<?php echo $i['allpage_top_image']; ?>"/>
                        <h3>New Logo</h3>
                        
                        <input type="file" class="form-control" name="new_photo" />
                      </div>

                      <button type="submit" class="btn btn-gradient-primary me-2" style="float:right;">Update</button>
                      <!--<button class="btn btn-light">Cancel</button>-->
                    </form>
                  </div>
                </div>
              </div>
            </div>
          <?php } ?>
             

            