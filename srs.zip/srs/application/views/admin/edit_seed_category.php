
        <!-- partial -->
        <div class="main-panel">
          <div class="content-wrapper">
            <div class="page-header">
              <h3 class="page-title">  Update Seed Category </h3>
              <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                  <li class="breadcrumb-item"><a href="#">Seed Category</a></li>
                  <li class="breadcrumb-item active" aria-current="page">Dashboard</li>
                </ol>
              </nav>
            </div>
            <?php  foreach($seed_category as $row){?>
            
            <div class="row"  >
              <div class="col-md-12 grid-margin stretch-card" id="add_page" style="display:block;" >
                <div class="card">
                  <div class="card-body">
                      <!-- <a class="btn btn-danger" onclick="allPages()" style="float:right;">All Pages</a> -->
                    <h4 class="card-title">Update Page</h4>
                    <!--<p class="card-description"> Basic form layout </p>-->
                   <form class="forms-sample" action="<?= base_url('Form/update_seed_category'); ?>/<?= $row['id'];?>" method="POST" enctype="multipart/form-data">
                        <div class="form-group">
                        <label for="name">Category Name</label>
                        <input type="text" class="form-control" id="name" name="name" value="<?= $row['name']; ?>" required>
                      </div>
                     
                      
                       <button type="submit" class="btn btn-gradient-primary me-2" name="submit" style="float:right;">Update</button>
                      <!--<button class="btn btn-light">Cancel</button>-->
                    </form>
                    
                  </div>
                </div>
              </div>
            </div>
<?php } ?>
             
           
           
     
            