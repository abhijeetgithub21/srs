
        <!-- partial -->
        <div class="main-panel">
          <div class="content-wrapper">
            <div class="page-header">
              <h3 class="page-title">  Manage Seed Category </h3>
              <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                  <li class="breadcrumb-item"><a href="#">Seed Category</a></li>
                  <li class="breadcrumb-item active" aria-current="page">Seed</li>
                </ol>
              </nav>
            </div>
            
            
            <div class="row"  >
              <div class="col-md-6 grid-margin stretch-card" id="add_seed_category" style="display:none;" >
                <div class="card">
                  <div class="card-body">
                      <a class="btn btn-danger" onclick="allSeedCategory()" style="float:right;">All Seed Categories</a>
                    <h4 class="card-title">Add Gardner</h4>
                    <!--<p class="card-description"> Basic form layout </p>-->
                   <form class="forms-sample" action="<?= base_url('Form/add_seed_category'); ?>" method="POST" enctype="multipart/form-data">
                        <div class="form-group">
                        <label for="name">Category Name </label>
                        <input type="text" class="form-control" id="name" name="name"  required>
                      </div>
                     
                       <button type="submit" class="btn btn-gradient-primary me-2" name="submit" style="float:right;">Submit</button>
                      <!--<button class="btn btn-light">Cancel</button>-->
                    </form>
                    
                  </div>
                </div>
              </div>
             
           
           <div class="col-lg-12 grid-margin stretch-card" id="all_seed_category">
                <div class="card">
                  <div class="card-body">
                       <?php 
                        if ($this->session->flashdata('msg') != ''): ?>
                        <div class="alert alert-success close" role="alert">
                              <?php echo $this->session->flashdata('msg');  ?>
                            </div>
                            <?php endif; ?>
                    <a class="btn btn-danger" onclick="addSeedCategory()">Add Seed Category</a>
                    <div class="table-responsive pt-3">
                    <table class="table table-bordered" id="myTable">
                      <thead>
                        <tr>
                          <th> # </th>
                          <th>Category Name</th>
                          <th>Action </th>
                        </tr>
                      </thead>
                      <tbody>
                          <?php $i = 1; foreach($seed_category as $row){ ?>
                        <tr>
                          <td> <?php echo $i++ ?> </td>
                          <td> <?= $row['name']; ?> </td>
                          <td>
                            <a href="<?= base_url('Dashboard/edit_seed_category'); ?>/<?php echo $row['id'] ?>" class="btn btn-sm btn-outline-primary"><i class="fas fa-edit"></i> Edit</a>
                              <a href="<?= base_url('Form/delete_seed_category'); ?>/<?php echo $row['id'] ?>" class="btn btn-sm btn-outline-danger"><i class="fas fa-trash-alt"></i> Delete</a>
                          </td>
                        </tr>
                        <?php } ?>
                      </tbody>
                    </table>
                    </div>
                  </div>
                </div>
              </div>
           <script>
function addSeedCategory() {
  document.getElementById("add_seed_category").style.display = "block";
  document.getElementById("all_seed_category").style.display = "none";
}
function allSeedCategory(){
    document.getElementById("add_seed_category").style.display = "none";
    document.getElementById("all_seed_category").style.display = "block";
}
</script>


            