
        <!-- partial -->
        <div class="main-panel">
          <div class="content-wrapper">
            <div class="page-header">
              <h3 class="page-title">  Manage Testimonials </h3>
              <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                  <li class="breadcrumb-item"><a href="#">Testimonials</a></li>
                  <li class="breadcrumb-item active" aria-current="page">
                      Dashboard
                  </li>
                </ol>
              </nav>
            </div>
            
            
         
            <div class="row">
              <div class="col-md-6 grid-margin stretch-card" id="add_testimonial" style="display:none;">
                <div class="card">
                  <div class="card-body">
                     <a class="btn btn-danger" onclick="alltestimonial()">All Testimonial</a>
                    <h4 class="card-title">Add Testimonial</h4>
                    <!--<p class="card-description"> Basic form layout </p>-->
                    <form class="forms-sample" action="<?= base_url('form/addtestimonial'); ?>" method="POST" enctype="multipart/form-data">
                        
            					<div class="form-group">
            						<h3>Image</h3>
            						
            						<input type="file" class="form-control" name="image"id="image" required/>
            					</div>
                      <div class="form-group">
                        <label for="name">Name</label>
                        <input type="text" class="form-control" id="name" name="name" required>
                      </div>
                      <div class="form-group">
                        <label for="position">Position</label>
                        <input type="text" class="form-control" id="position" name="position">
                      </div>
                       <div class="form-group">
                        <label for="message">Message</label>
                        <textarea name="message" id="message" class="form-control" rows="10"></textarea>
                      </div>
                     
                      
                       <button type="submit" class="btn btn-gradient-primary me-2" style="float:right;">Submit</button>
                      <!--<button class="btn btn-light">Cancel</button>-->
                    </form>
                    
                  </div>
                </div>
              </div>
             
             
             
              <div class="col-lg-12 grid-margin stretch-card" id="all_testimonial">
                <div class="card">
                  <div class="card-body">
                    <a class="btn btn-danger" onclick="addtestimonial()">Add Testimonials</a>
                    <div class="table-responsive pt-3">
                    <table class="table table-bordered" id="myTable" >
                      <thead>
                        <tr>
                          <th> # </th>
                          <th> Image </th>
                          <th> Name </th>
                          <th> Position </th>
                          <th>Message </th>
                          <th> Action </th>
                        </tr>
                      </thead>
                      <tbody>
                          <?php $i = 1; foreach($testimonial as $row){ ?>
                        <tr>
                          <td> <?php echo $i++ ?> </td>
                          <td> <img src="<?= base_url(); ?>_assets/upload/person/<?= $row['image']; ?>" hight="100px" weight="100px"> </td>
                          <td> <?= $row['name']; ?> </td>
                          <td> <?= $row['position']; ?> </td>
                          <td> <?= $row['message']; ?> </td>
                          <td>
                              <a href="<?= base_url('dashboard/testimonial_edit'); ?>/<?php echo $row['id'] ?>" class="btn btn-sm btn-success"><i class="fas fa-edit"></i>Edit</a>&nbsp;&nbsp;
                              <a href="<?= base_url('form/delete_testimonial'); ?>/<?= $row['id']; ?>" class="btn btn-sm btn-primary"><i class="fas fa-trash-alt"></i> Delete</a>
                          </td>
                        </tr>
                        <?php } ?>
                      </tbody>
                    </table>
                    </div>
                  </div>
                </div>
              </div>
<script>
    function addtestimonial() {
      document.getElementById("add_testimonial").style.display = "block";
      document.getElementById("all_testimonial").style.display = "none";
    }
    function alltestimonial(){
        document.getElementById("add_testimonial").style.display = "none";
        document.getElementById("all_testimonial").style.display = "block";
    }
</script>

            
            