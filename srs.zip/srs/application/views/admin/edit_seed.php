
        <!-- partial -->
        <div class="main-panel">
          <div class="content-wrapper">
            <div class="page-header">
              <h3 class="page-title">  Update Seed </h3>
              <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                  <li class="breadcrumb-item"><a href="#">Seeds</a></li>
                  <li class="breadcrumb-item active" aria-current="page">Dashboard</li>
                </ol>
              </nav>
            </div>
            <?php  foreach($seeds as $s){?>
            
            <div class="row"  >
              <div class="col-md-12 grid-margin stretch-card" id="add_page" style="display:block;" >
                <div class="card">
                  <div class="card-body">
                      <!-- <a class="btn btn-danger" onclick="allPages()" style="float:right;">All Pages</a> -->
                    <h4 class="card-title">Update Page</h4>
                    <!--<p class="card-description"> Basic form layout </p>-->
                   <form class="forms-sample" action="<?= base_url('Form/update_seed/'); ?><?= $s['id'];?>" method="POST" enctype="multipart/form-data">
                        <div class="form-group">
                        <label for="name">Name </label>
                        <input type="text" class="form-control" id="name" name="name" value="<?= $s['name']; ?>"  required>
                      </div>
                      <div class="form-group">
                        <label for="category">Category Name </label>
                       <select class="form-control" name="category" id="category">
                        <option value=""> if you not want to change </option>
                        <?php foreach($seed_category as $row){ ?>
                        <option value="<?= $row['id']; ?>"><?= $row['name']; ?></option>
                        <?php } ?>
                       </select>
                      </div>
                       <label for="old_image">Old Image</label> 
                      <div class="form-group">
                          <img src="<?= base_url();?>_assets/upload/seeds/<?= $s['image']; ?>" alt="image not found" width="200">
                          <input type="hidden" name="old_image" id="old_image" value="<?= $s['image']; ?>">
                      </div>
                       <div class="form-group">
                        <label for="image">New Image  </label>
                        <input type="file" class="form-control" id="image" name="image">
                      </div>
                       <div class="form-group">
                        <label for="expiry_date">Expiry Date </label>
                        <input type="date" class="form-control" id="expiry_date" value="<?= $s['expiry_date']; ?>" name="expiry_date"  required>
                      </div>
                       <div class="form-group">
                        <label for="quantity">Quantiy (in Kg) </label>
                        <input type="number" class="form-control" id="quantity" name="quantity" value="<?= $s['quantity']; ?>"  required>
                      </div>
                     
                       <button type="submit" class="btn btn-gradient-primary me-2" name="submit" style="float:right;">Submit</button>
                      <!--<button class="btn btn-light">Cancel</button>-->
                    </form>
                    
                  </div>
                </div>
              </div>
            </div>
<?php } ?>
             
           
           
     
            