
        <!-- partial -->
        <div class="main-panel">
          <div class="content-wrapper">
            <div class="page-header">
              <h3 class="page-title">  Manage Carousel </h3>
              <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                  <li class="breadcrumb-item"><a href="#">Carousel</a></li>
                  <li class="breadcrumb-item active" aria-current="page">
                      Dashboard
                  </li>
                </ol>
              </nav>
            </div>
            
            
         
            <div class="row">
              <div class="col-md-6 grid-margin stretch-card" id="add_carousel" style="display:none;">
                <div class="card">
                  <div class="card-body">
                     <a class="btn btn-danger" onclick="allCarousel()">All Carousel</a>
                    <h4 class="card-title">Add Carousel</h4>
                    <!--<p class="card-description"> Basic form layout </p>-->
                    <form class="forms-sample" action="<?= base_url('form/add_carousel'); ?>" method="POST" enctype="multipart/form-data">
                        
					<div class="form-group">
						<h3>Image</h3>
						<!--<img src="" height="44%" width="55%" />-->
						<!--<input type="hidden" name="previous" value=""/>-->
						<!--<h3>New Logo</h3>-->
						<input type="file" class="form-control" name="image"id="image" required/>
					</div>
                      <div class="form-group">
                        <label for="title">Title</label>
                        <input type="text" class="form-control" id="title" name="title" required>
                      </div>
                      <div class="form-group">
                        <label for="description">Description</label>
                        <input type="text" class="form-control" id="description" name="description">
                      </div>
                       <div class="form-group">
                        <label for="link">Link</label>
                        <input type="text" class="form-control" id="link" name="link">
                      </div>
                     
                      
                       <button type="submit" class="btn btn-gradient-primary me-2" style="float:right;">Submit</button>
                      <!--<button class="btn btn-light">Cancel</button>-->
                    </form>
                    
                  </div>
                </div>
              </div>
             
             
             
              <div class="col-lg-12 grid-margin stretch-card" id="all_carousel">
                <div class="card">
                  <div class="card-body">
                    <a class="btn btn-danger" onclick="addCarousel()">Add Carousel</a>
                    <div class="table-responsive pt-3">
                    <table class="table table-bordered" id="myTable">
                      <thead>
                        <tr>
                          <th> # </th>
                          <th> Icon </th>
                          <th> Heading </th>
                          <th> Description </th>
                          <th>Link </th>
                          <th> Action </th>
                        </tr>
                      </thead>
                      <tbody>
                          <?php $i = 1; foreach($carousel as $row){ ?>
                        <tr>
                          <td> <?php echo $i++ ?> </td>
                          <td> <img src="<?= base_url(); ?>_assets/upload/carousel/<?= $row['image']; ?>" hight="100px" weight="100px"> </td>
                          <td> <?= $row['title']; ?> </td>
                          <td> <?= $row['description']; ?> </td>
                          <td> <a href="<?= $row['link']; ?>">Link</a> </td>
                          <td>
                              <a href="<?= base_url('dashboard/carousel_edit'); ?>/<?php echo $row['id'] ?>" class="btn btn-sm btn-success"><i class="fas fa-edit"></i>Edit</a>&nbsp;&nbsp;
                              <a href="<?= base_url('form/delete_carousel'); ?>/<?= $row['id']; ?>" class="btn btn-sm btn-primary"><i class="fas fa-trash-alt"></i> Delete</a>
                          </td>
                        </tr>
                        <?php } ?>
                      </tbody>
                    </table>
                    </div>
                  </div>
                </div>
              </div>
<script>
    function addCarousel() {
      document.getElementById("add_carousel").style.display = "block";
      document.getElementById("all_carousel").style.display = "none";
    }
    function allCarousel(){
        document.getElementById("add_carousel").style.display = "none";
        document.getElementById("all_carousel").style.display = "block";
    }
</script>

            
            