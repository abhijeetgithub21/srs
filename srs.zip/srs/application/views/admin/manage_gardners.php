
        <!-- partial -->
        <div class="main-panel">
          <div class="content-wrapper">
            <div class="page-header">
              <h3 class="page-title">  Manage Gardners </h3>
              <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                  <li class="breadcrumb-item"><a href="#">Gardners</a></li>
                  <li class="breadcrumb-item active" aria-current="page">Users</li>
                </ol>
              </nav>
            </div>
            
            
            <div class="row"  >
              <div class="col-md-6 grid-margin stretch-card" id="add_gardner" style="display:none;" >
                <div class="card">
                  <div class="card-body">
                      <a class="btn btn-danger" onclick="allServices()" style="float:right;">All Gardner</a>
                    <h4 class="card-title">Add Gardner</h4>
                    <!--<p class="card-description"> Basic form layout </p>-->
                   <form class="forms-sample" action="<?= base_url('Form/add_gardner'); ?>" method="POST" enctype="multipart/form-data">
                        <div class="form-group">
                        <label for="name">Name</label>
                        <input type="text" class="form-control" id="name" name="name"  required>
                      </div>
                      <div class="form-group">
                        <label for="email">Email</label>
                        <input type="email" class="form-control" id="email" name="email"  required>
                      </div>
                      <div class="form-group">
                        <label for="mobile">Mobile</label>
                        <input type="text" class="form-control" id="mobile" name="mobile"  required>
                      </div>
                       <button type="submit" class="btn btn-gradient-primary me-2" name="submit" style="float:right;">Submit</button>
                      <!--<button class="btn btn-light">Cancel</button>-->
                    </form>
                    
                  </div>
                </div>
              </div>
             
           
           <div class="col-lg-12 grid-margin stretch-card" id="all_gardner">
                <div class="card">
                  <div class="card-body">
                       <?php 
                        if ($this->session->flashdata('msg') != ''): ?>
                        <div class="alert alert-success close" role="alert">
                              <?php echo $this->session->flashdata('msg');  ?>
                            </div>
                            <?php endif; ?>
                    <a class="btn btn-danger" onclick="myFunction()">Add Gardner</a>
                    <div class="table-responsive pt-3">
                    <table class="table table-bordered" id="myTable">
                      <thead>
                        <tr>
                          <th> # </th>
                          <th>Name</th>
                          <th>Email</th>
                          <th>Mobile</th>
                          <th>Address</th>
                          <th>Action </th>
                        </tr>
                      </thead>
                      <tbody>
                          <?php $i = 1; foreach($gardners as $row){ ?>
                        <tr>
                          <td> <?php echo $i++ ?> </td>
                          <td> <?= $row['name']; ?> </td>
                          <td> <?= $row['email']; ?> </td>
                          <td> <?= $row['mobile']; ?> </td>
                           <td> <?= $row['address']; ?> </td>
                                
                          <td>
                            <a href="<?= base_url('Dashboard/edit_gardner'); ?>/<?php echo $row['id'] ?>" class="btn btn-sm btn-primary"><i class="fas fa-edit"></i> Edit</a>
                              <a href="<?= base_url('Form/delete_gardner'); ?>/<?php echo $row['id'] ?>" class="btn btn-sm btn-primary"><i class="fas fa-trash-alt"></i> Delete</a>
                          </td>
                        </tr>
                        <?php } ?>
                      </tbody>
                    </table>
                    </div>
                  </div>
                </div>
              </div>
           <script>
function myFunction() {
  document.getElementById("add_gardner").style.display = "block";
  document.getElementById("all_gardner").style.display = "none";
}
function allServices(){
    document.getElementById("add_gardner").style.display = "none";
    document.getElementById("all_gardner").style.display = "block";
}
</script>


            