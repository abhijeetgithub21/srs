
        <!-- partial -->
        <div class="main-panel">
          <div class="content-wrapper">
            <div class="page-header">
              <h3 class="page-title">  Update Carousel </h3>
              <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                  <li class="breadcrumb-item"><a href="#">Update</a></li>
                  <li class="breadcrumb-item active" aria-current="page">
                      Carousel
                  </li>
                </ol>
              </nav>
            </div>
            
            <?php foreach($carousel as $row){?>
         
            <div class="row">
              <div class="col-md-6 grid-margin stretch-card" id="add_carousel" style="display:block;">
                <div class="card">
                  <div class="card-body">
                     <!--<a class="btn btn-danger" onclick="allCarousel()">All Carousel</a>-->
                    <h4 class="card-title">Update Carousel</h4>
                    <!--<p class="card-description"> Basic form layout </p>-->
                    <form class="forms-sample" action="<?= base_url('Form/update_carousel'); ?>" method="POST" enctype="multipart/form-data">
                        
					<div class="form-group">
						<h3>Current Logo</h3>
						<img src="<?php echo base_url(); ?>_assets/upload/carousel/<?php echo $row['image']; ?>" height="44%" width="55%" />
						<input type="hidden" name="old_photo" value="<?php echo $row['image']; ?>"/>
						<h3>New Logo</h3>
						
						<input type="file" class="form-control" name="new_photo" />
					</div>
                      <div class="form-group">
                        <label for="title">Title</label>
                        <input type="text" class="form-control" id="title" name="title" value="<?= $row['title']; ?>" required>
                        <input type="hidden" name="id" id="id" value="<?= $row['id']; ?>">
                      </div>
                      <div class="form-group">
                        <label for="description">Description</label>
                        <textarea class="form-control" id="description" name="description" row="10"><?= $row['description']; ?></textarea>
                        <!--<input type="text" class="form-control" id="description" name="description" value="<?= $row['paragraph']; ?>" required>-->
                      </div>

                      <div class="form-group">
                        <label for="description">Link</label>
                        <input type="text" class="form-control" id="link" name="link" value="<?= $row['link']; ?>" required>
                      </div>
                     
                      
                       <button type="submit" class="btn btn-gradient-primary me-2" style="float:right;">Submit</button>
                      <!--<button class="btn btn-light">Cancel</button>-->
                    </form>
                    
                  </div>
                </div>
              </div>
             
             
             <?php } ?>
             
   