
        <!-- partial -->
        <div class="main-panel">
          <div class="content-wrapper">
            <div class="page-header">
              <h3 class="page-title">  Update testimonial </h3>
              <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                  <li class="breadcrumb-item"><a href="#">Update</a></li>
                  <li class="breadcrumb-item active" aria-current="page">
                      testimonial
                  </li>
                </ol>
              </nav>
            </div>
            
            <?php foreach($testimonial as $row){?>
         
            <div class="row">
              <div class="col-md-6 grid-margin stretch-card" id="add_testimonial" style="display:block;">
                <div class="card">
                  <div class="card-body">
                     <!--<a class="btn btn-danger" onclick="alltestimonial()">All testimonial</a>-->
                    <h4 class="card-title">Update testimonial</h4>
                    <!--<p class="card-description"> Basic form layout </p>-->
                    <form class="forms-sample" action="<?= base_url('Form/update_testimonial/'); ?><?= $row['id']; ?>" method="POST" enctype="multipart/form-data">
                        
          					<div class="form-group">
          						<h3>Current Logo</h3>
          						<img src="<?php echo base_url(); ?>_assets/upload/person/<?php echo $row['image']; ?>" height="44%" width="55%" />
          						<input type="hidden" name="old_photo" value="<?php echo $row['image']; ?>"/>
          						<h3>New Logo</h3>
          						
          						<input type="file" class="form-control" name="new_photo" />
          					</div>
                      <div class="form-group">
                        <label for="name">Name</label>
                        <input type="text" class="form-control" id="name" name="name" value="<?= $row['name']; ?>" required>
                        <input type="hidden" name="id" id="id" value="<?= $row['id']; ?>">
                      </div>
                       <div class="form-group">
                        <label for="position">Position</label>
                        <input type="text" class="form-control" id="position" name="position" value="<?= $row['position']; ?>" required>
                      </div>
                      <div class="form-group">
                        <label for="message">message</label>
                        <textarea class="form-control" id="message" name="message" row="10"><?= $row['message']; ?></textarea>
                      </div>

                     
                     
                      
                       <button type="submit" class="btn btn-gradient-primary me-2" style="float:right;">Update</button>
                      <!--<button class="btn btn-light">Cancel</button>-->
                    </form>
                    
                  </div>
                </div>
              </div>
             
             
             <?php } ?>
             
   