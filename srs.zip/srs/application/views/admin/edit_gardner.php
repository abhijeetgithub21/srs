
        <!-- partial -->
        <div class="main-panel">
          <div class="content-wrapper">
            <div class="page-header">
              <h3 class="page-title">  Update Gardner </h3>
              <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                  <li class="breadcrumb-item"><a href="#">Update Gardner</a></li>
                  <li class="breadcrumb-item active" aria-current="page">Dashboard</li>
                </ol>
              </nav>
            </div>
            <?php  foreach($users as $row){?>
            
            <div class="row"  >
              <div class="col-md-12 grid-margin stretch-card" id="add_page" style="display:block;" >
                <div class="card">
                  <div class="card-body">
                      <!-- <a class="btn btn-danger" onclick="allPages()" style="float:right;">All Pages</a> -->
                    <h4 class="card-title">Update Page</h4>
                    <!--<p class="card-description"> Basic form layout </p>-->
                   <form class="forms-sample" action="<?= base_url('Form/update_gardner'); ?>/<?= $row['id'];?>" method="POST" enctype="multipart/form-data">
                        <div class="form-group">
                        <label for="name">Name</label>
                        <input type="text" class="form-control" id="name" name="name" value="<?= $row['name']; ?>" required>
                      </div>
                      <div class="form-group">
                        <label for="email">Email</label>
                        <input type="email" class="form-control" id="email" name="email" value="<?= $row['email']; ?>" required>
                      </div>
                      <div class="form-group">
                        <label for="mobile">Mobile</label>
                        <input type="text" class="form-control" id="mobile" name="mobile" value="<?= $row['mobile']; ?>" required>
                      </div>
                       <div class="form-group">
                        <label for="address">Address</label>
                        <input type="text" class="form-control" id="address" name="address" value="<?= $row['address']; ?>" required>
                      </div>
                      
                      
                       <button type="submit" class="btn btn-gradient-primary me-2" name="submit" style="float:right;">Update</button>
                      <!--<button class="btn btn-light">Cancel</button>-->
                    </form>
                    
                  </div>
                </div>
              </div>
            </div>
<?php } ?>
             
           
           
     
            