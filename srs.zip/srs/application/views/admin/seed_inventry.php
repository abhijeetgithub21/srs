
        <!-- partial -->
        <div class="main-panel">
          <div class="content-wrapper">
            <div class="page-header">
              <h3 class="page-title">  Seed Enventry </h3>
              <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                  <li class="breadcrumb-item"><a href="#">Seed Enventry</a></li>
                  <li class="breadcrumb-item active" aria-current="page">Dashboard</li>
                </ol>
              </nav>
            </div>
            
            
            <div class="row"  >
              <div class="col-md-6 grid-margin stretch-card" id="add_inventory" style="display:none;" >
                <div class="card">
                  <div class="card-body">
                      <a class="btn btn-outline-danger" onclick="allInventory()" style="float:right;">All Inventory</a>
                    <h4 class="card-title">Add Inventory</h4>
                    <!--<p class="card-description"> Basic form layout </p>-->
                   <form class="forms-sample" action="<?= base_url('Form/add_inventory'); ?>" method="POST" enctype="multipart/form-data">

                     <div class="form-group">
                      <label for="inventory_status">Inventory Status </label>
                       <select class="form-select" aria-label="Default select example" name="inventory_status" id="inventory_status" >
                          <option value="1">Purchase</option>
                          <option value="2"> Sell </option>
                       </select>
                      </div>

                       <div class="form-group">
                        <label for="seed">Seed </label>
                       <select class="form-select" aria-label="Default select example" name="seed" id="seed" >
                        <?php foreach($seeds as $seed){ ?>
                        <option  value="<?= $seed['id']; ?>"><?= $seed['name']; ?></option>
                      <?php } ?>
                       </select>
                      </div>
                       <div class="form-group">
                        <label for="quantity">Quantity (in Kg)</label>
                        <input type="number" class="form-control" id="quantity" name="quantity"  required step="any">
                      </div>
                      <div class="form-group" style="text-align:right;">
                        <a href="<?= base_url('dashboard/manage_seeds'); ?>" target="_blank"> View Seed List</a>
                      </div>
                      <div class="form-group">
                        <label for="name">Name</label>
                        <input type="text" class="form-control" id="name" name="name"  required>
                      </div>
                      <div class="form-group">
                        <label for="email">Email</label>
                        <input type="email" class="form-control" id="email" name="email" >
                      </div>
                      <div class="form-group">
                        <label for="mobile">Mobile</label>
                        <input type="text" class="form-control" id="mobile" name="mobile"  required>
                      </div>
                       <div class="form-group">
                        <label for="address">Address</label>
                       <textarea name="address" id="address" rows="5" class="form-control"></textarea>
                      </div>
                      

                       <button type="submit" class="btn btn-gradient-primary me-2" name="submit" style="float:right;">Submit</button>
                      <!--<button class="btn btn-light">Cancel</button>-->
                    </form>
                    
                  </div>
                </div>
              </div>
             
           
           <div class="col-lg-12 grid-margin stretch-card" id="all_inventory">
                <div class="card">
                  <div class="card-body">
                       <?php 
                        if ($this->session->flashdata('msg') != ''): ?>
                        <div class="alert alert-success close" role="alert">
                              <?php echo $this->session->flashdata('msg');  ?>
                            </div>
                            <?php endif; ?>
                    <a class="btn btn-outline-danger" onclick="addInventory()">Add Inventory</a>
                    <div class="table-responsive pt-3">
                    <table class="table table-bordered" id="myTable">
                      <thead>
                        <tr>
                          <th> # </th>
                          <th>Inventory Status</th>
                          <th>Category</th>
                          <th>Seed Name</th>
                          <th>Date</th>
                          <th>Time</th>
                          <th>Expiry Date</th>
                          <th>Name </th>
                          <th>Email </th>
                          <th>Mobile</th>
                          <th>Address </th>
                          <th>Quantity (in Kg)</th>
                          <th>Invoice Number</th>
                          <th>Action </th>
                        </tr>
                      </thead>
                      <tbody>
                          <?php $i = 1; foreach($seed_inventry as $row){ ?>
                        <tr>
                          <td> <?php echo $i++ ?> </td>
                          <td><?php 
                          if($row['inventory_status'] == 1){
                            echo "Purchased";
                          }else{
                            echo "Sold";
                          }

                        ?></td>
                          <td> 
                            <?php foreach($seed_category as $c){
                                if($c['id'] == $row['seed_category_id'] ){
                                  echo $c['name'];
                                }
                              }?>

                        </td>
                          <td> 

                          <?php foreach($seeds as $s){
                                if($s['id'] == $row['seed_id'] ){
                                  echo $s['name'];
                                }
                              }?>
                           </td>
                          <td> <?= $row['date']; ?> </td>
                          <td> <?= $row['time']; ?> </td>
                          <td> <?= $row['expiry_date']; ?> </td>
                          <td> <?= $row['name']; ?> </td>
                          <td> <?= $row['email']; ?> </td>
                          <td> <?= $row['mobile']; ?> </td>
                          <td> <?= $row['address']; ?> </td>
                          <td> <?= $row['quantity']; ?> </td>
                          <td> <?= $row['invoice_number']; ?> </td>
                             
                          <td>
                            <!-- <a href="<?= base_url('Dashboard/edit_inventory'); ?>/<?php echo $row['id'] ?>" class="btn btn-sm btn-primary"><i class="fas fa-edit"></i> Edit</a> -->
                              <a href="<?= base_url('Form/delete_inventory'); ?>/<?php echo $row['id'] ?>" class="btn btn-sm btn-danger"><i class="fas fa-trash-alt"></i> Delete</a>
                          </td>
                        </tr>
                        <?php } ?>
                      </tbody>
                    </table>
                    </div>
                  </div>
                </div>
              </div>
           <script>
function addInventory() {
  document.getElementById("add_inventory").style.display = "block";
  document.getElementById("all_inventory").style.display = "none";
}
function allInventory(){
    document.getElementById("add_inventory").style.display = "none";
    document.getElementById("all_inventory").style.display = "block";
}
</script>


            