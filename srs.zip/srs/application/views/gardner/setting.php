<?php 
include_once('elements/header.php');
include_once('elements/sidebar.php');
?>
        <!-- partial -->
        <div class="main-panel">
          <div class="content-wrapper">
            <div class="page-header">
              <h3 class="page-title">  Update Details </h3>
              <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                  <li class="breadcrumb-item"><a href="#">Update Details</a></li>
                  <li class="breadcrumb-item active" aria-current="page">Gardner</li>
                </ol>
              </nav>
            </div>
       <?php if(!empty($this->session->flashdata('msg'))) {?> 
    <div class="alert alert-success">
       <?php echo $this->session->flashdata('msg'); ?>
    </div>
<?php } ?>
          <div class="row">
              <?php foreach($users as $u){?>
              <div class="col-md-6 grid-margin stretch-card">
                <div class="card">
                  <div class="card-body">
                    <h4 class="card-title"> Gardner Details</h4>
                     <div class="form-control">
                      <form action="<?= base_url('gardner/update_detail/'); ?><?= $u['id']; ?>" method="post">
                      <div class="form-group">
                        <label for="name">Name</label>
                        <input type="text" class="form-control" id="name" name="name" value="<?= $u['name']; ?>" required>
                        <input type="hidden" name="id" value="<?= $u['id']; ?>" >
                      </div> 
                      <div class="form-group">
                        <label for="email">Email Or Username</label>
                        <input type="email" class="form-control" id="email" name="email" value="<?= $u['email']; ?>" required>
                      </div> 
                      <div class="form-group">
                        <label for="mobile">Mobile</label>
                        <input type="text" class="form-control" id="mobile" name="mobile" value="<?= $u['mobile']; ?>" >
                      </div>  
                       <div class="form-group">
                        <label for="address">Address</label>
                        <textarea class="form-control" name="address" id="address" rows="10"><?= $u['address']; ?></textarea>
                      </div>                  
                      <button type="submit" class="btn btn-gradient-primary me-2" style="float:right;">Update</button>
                      <!--<button class="btn btn-light">Cancel</button>-->
                    </form>
                  </div>
                </div>
              </div>
            </div>
            <?php } ?>
<?php foreach($users as $u){?>
            <div class="col-md-6 grid-margin stretch-card">
                <div class="card">
                  <div class="card-body">
                    <h4 class="card-title"> Change Password</h4>
                     <div class="form-control">
                      <form action="<?= base_url('employee/change_pass/'); ?><?= $u['id']; ?>" method="post">
                      <div class="form-group">
                        <label for="old_pass">Current Password</label>
                        <input type="text" class="form-control" id="old_pass" name="old_pass" required>
                      </div> 
                      <div class="form-group">
                        <label for="new_pass">New Password</label>
                        <input type="password" class="form-control" id="new_pass" name="new_pass" required>
                      </div> 
                      <div class="form-group">
                        <label for="c_new_pass">Re-type New Password</label>
                        <input type="text" class="form-control" id="c_new_pass" name="c_new_pass" required>
                      </div>  
                                
                      <button type="submit" class="btn btn-gradient-primary me-2" style="float:right;">Update</button>
                      <!--<button class="btn btn-light">Cancel</button>-->
                    </form>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <?php }?>
  <?php 
include_once('elements/footer.php');
?>