<?php 
require_once('header.php');

?>
<?php foreach($images as $i){?>
 <div class="hero-wrap hero-bread" style="background-image: url(<?= base_url('_assets/upload/top_images/'); ?><?= $i['allpage_top_image']; ?>)">
      <div class="container">
        <div class="row no-gutters slider-text align-items-center justify-content-center">
          <div class="col-md-9 ftco-animate text-center">
          	<p class="breadcrumbs"><span class="mr-2"><a href="<?= base_url(); ?>">Home</a></span> <span><?= $title; ?></span></p>
            <h1 class="mb-0 bread"><?= $title; ?></h1>
          </div>
        </div>
      </div>
    </div>
<?php } ?>

<div class="container">
<?php 
foreach($pages as $row){
	echo $row['content'];
}
?>

	</div>
 <?php
require_once('footer.php');
?>
