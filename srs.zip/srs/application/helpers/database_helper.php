<?
function insert_data($table = '', $data = array() , $condition = FALSE, $MSG = array('error'=>'','success'=>''),$condition_data = array()){
	$CI = get_instance();
	$CI->load->database();
	if(!empty($table)){
		
		$con_data = ( count($condition_data) > 0 ) ? $condition_data : $data;


		$return = array('status'=>false,'data'=>array());
		$check = true;

		if(!is_array($data) || empty($data)){
			echo 'Data is NULL , Please Provide Data.';
			exit;
		}
		
		if($condition){
			if($CI->db->get_where($table,$con_data)->num_rows()){
				$CI->session->set_flashdata('error',$MSG['error']);
				return false;
			}
		}


		if($check){
			$CI->session->set_flashdata('success',$MSG['success']);
			$CI->db->insert($table,$data);	
			return $CI->db;		 
		}
	}
	else{
		$_error =& load_class('Exceptions', 'core');
		$_error->show_php_error('ERROR', 'Table name is not Empty.','','');
	}
}

function FETCH_TABLE_DATA($table = '', $data = array() ){
  
	  $CI = get_instance();

	  $CI->load->database();

	  if($table == trim($table) && strpos($table, ' ') !== false)
	  	  return $CI->db->query($table);


	  if(count($data))
		  	$CI->db->where($data);

	  return $CI->db->get($table);
}

?>