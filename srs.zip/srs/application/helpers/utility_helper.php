<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

     if ( ! function_exists('asset_url()'))
     {
       function asset_url()
       {
          return base_url().'assets/';
       }
     }


     if ( ! function_exists('admin_asset_url()'))
     {
       function admin_asset_url()
       {
          return base_url().'admin_assets/';
       }
     }
    if(!function_exists('set_country_code')){
        function set_country_code($number){
            // return $number;
            if(  ( substr($number,0,2 )  == '91' )  AND strlen($number) > 10)
                    $number = "+$number";
            else if(strpos('+91',$number) === FALSE){
                $number = "+91$number";
            }
            return $number;
            
        }
    }
 ?>