<?
function get_table_data($id,$table)
{
    $CI = get_instance();
	$CI->load->database();
	$data =  $CI->db->where('id',$id)->get($table);
	if($data->num_rows())
	    return $data->row()->name;
	else
	    return '<label class="label label-danger text-danger" style="color:red">'.ucwords($table).' is Deleted!!</label>';
}
?>