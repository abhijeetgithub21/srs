<?

function EC($id){
    return str_replace('/','A_J',get_instance()->encryption->encrypt($id));
}
function ED($id){

    return get_instance()->encryption->decrypt(str_replace('A_J','/',$id));

}
    function allMenu(){
        $CI = get_instance();
        $m = $CI->db->order_by('sort')->get('menu');
        $ref = $items   = [];
        if(count($m->result())){

            foreach($m->result() as $k => $data) {

                $thisRef = &$ref[$data->id];
                $thisRef['parent']        =       $data->parent;
                $thisRef['type']          =       $data->type;
                $thisRef['page_name']     =       $data->label;
                $thisRef['link']          =       $data->link;
                $thisRef['page_id']       =       $data->page_id;
                $thisRef['target']        =        '';
                /*
                $chR = $this->SiteModel->list_page($data->page_id);
                if($chR->num_rows())
                  $thisRef['target'] = $chR->row()->redirection ? ' target="_blank" ' : '';*/

                if($data->parent == 0) 
                    $items[$data->id] = &$thisRef;
                else 
                    $ref[$data->parent]['child'][$data->id] = &$thisRef;
            }
            
        }
        
        return $items;
    }
    
    function page_data($id=0)
    {
        $CI = get_instance();
        return $CI->db->get_where('pages',['id'=>$id])->row();
    }
   function MENU($item = [], $class = '',$page_id = 0){
        $html = '<ul class="'.$class.'">';
        
            foreach($item as $id => $value){
                
                $pg = page_data($value['page_id']);
                
                
                 $link = site_url();
                 $active  = '';
                if( $page_id == $value['page_id'] )  
                    $active = 'active';
                else
                    $active = ( !$page_id && $pg->id == 1) ? 'current-menu-item page_item current_page_item active ' : '' ;
                
                if($pg->link!='')
                    $link = $pg->link;
                else if($pg->id==1){
                   $link = site_url();
                  // $active = !$page_id ? 'active' : '';
                }
                else
                    // $link = site_url().'Web/page/'.$pg->id;
                    
                $link = $link.($pg->link!=''?$pg->link:'website/page/'.$pg->id);
                
               // $active = ( $page_id == $value['page_id'] ) ? 'active' : '';
                
                $red = $pg->redirection=='on'?'_blank':'';
                
                
                
                if(array_key_exists('child',$value))
                    $html.= '<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children '.$active.'"><a  aria-current="page" class="nav-link"  href="javascript:void(0)" target="'.$red.'">'.$value['page_name'].'</a>'.MENU($value['child'],'sub-menu dropdown-content drop-tg',$page_id); 
                else
                    $html .= '<li class="menu-item menu-item-type-post_type menu-item-object-page  nav-item '.$active.'"><a aria-current="page" class="nav-link" href="'.$link.'" target="'.$red.'">'.$value['page_name'].'</a>';
                    
                    
                $html .=   '</li>';
                
            }
        
  
        return $html.'</ul>';
    }
   
?>