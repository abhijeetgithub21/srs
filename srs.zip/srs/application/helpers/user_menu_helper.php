<?
    function user_menu()
    {
        $CI = get_instance();
        echo ' <div class="breadcrumb">Welcome &nbsp; <b>'.ucwords($CI->session->user_name).'</b> <a href="'.site_url('Website/user-login').'" class="btn btn-danger btn-sm pull-right"><i class="fa fa-sign-out"></i></a></div>';
        echo '<div class="breadcrumb"><a href="'.site_url('User').'">Profile</a> &nbsp; | &nbsp; <a href="'.site_url('User/record').'">Record</a></div>';
    }
?>