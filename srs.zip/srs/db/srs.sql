-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 09, 2022 at 05:59 AM
-- Server version: 10.4.20-MariaDB
-- PHP Version: 8.0.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `srs`
--

-- --------------------------------------------------------

--
-- Table structure for table `carousel`
--

CREATE TABLE `carousel` (
  `id` int(11) NOT NULL,
  `image` varchar(120) NOT NULL,
  `title` text NOT NULL,
  `description` text NOT NULL,
  `link` varchar(120) NOT NULL,
  `status` int(11) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `carousel`
--

INSERT INTO `carousel` (`id`, `image`, `title`, `description`, `link`, `status`) VALUES
(1, 'bg_2.jpg', '100% Fresh & Organic Foods', 'We deliver organic vegetables & fruits', '#', 1),
(2, 'bg_1.jpg', '100% Fresh &amp; Organic Foods', 'We deliver organic vegetables &amp; fruits', '#', 1);

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `category_id` int(10) UNSIGNED NOT NULL,
  `category_name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `category_link` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `parent_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `sort_order` int(11) NOT NULL DEFAULT 0,
  `page_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`category_id`, `category_name`, `category_link`, `parent_id`, `sort_order`, `page_id`) VALUES
(1, 'Home', '', 0, 0, 0),
(2, 'About', 'welcome/about', 0, 0, 0),
(3, 'Contact', 'welcome/contact', 0, 0, 0),
(15, 'Product', 'welcome/shop', 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE `feedback` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `phone` varchar(12) NOT NULL,
  `subject` varchar(50) NOT NULL,
  `message` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`id`, `name`, `email`, `phone`, `subject`, `message`, `created_at`) VALUES
(1, 'abhijeet kumar', 'demo@gmail.com', '', 'hi', 'this is demo message', '2022-01-24 07:34:54');

-- --------------------------------------------------------

--
-- Table structure for table `footer_links`
--

CREATE TABLE `footer_links` (
  `id` int(11) NOT NULL,
  `name` varchar(150) NOT NULL,
  `link` varchar(150) NOT NULL,
  `status` int(11) NOT NULL DEFAULT 1,
  `page_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `images`
--

CREATE TABLE `images` (
  `id` int(11) NOT NULL,
  `allpage_top_image` varchar(120) NOT NULL,
  `status` int(11) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `images`
--

INSERT INTO `images` (`id`, `allpage_top_image`, `status`) VALUES
(1, 'bg_1.jpg', 1);

-- --------------------------------------------------------

--
-- Table structure for table `menu`
--

CREATE TABLE `menu` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `parent_id` int(11) NOT NULL DEFAULT 0,
  `page_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `menu`
--

INSERT INTO `menu` (`id`, `name`, `parent_id`, `page_id`) VALUES
(1, 'Home', 0, 0),
(2, 'About', 0, 2);

-- --------------------------------------------------------

--
-- Table structure for table `pages`
--

CREATE TABLE `pages` (
  `p_id` int(11) NOT NULL,
  `p_name` varchar(200) NOT NULL,
  `content` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `status` int(11) NOT NULL DEFAULT 1,
  `p_slug` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `seeds`
--

CREATE TABLE `seeds` (
  `id` int(11) NOT NULL,
  `name` varchar(120) NOT NULL,
  `category_id` int(11) NOT NULL,
  `expiry_date` varchar(100) NOT NULL,
  `image` varchar(120) NOT NULL,
  `status` int(11) NOT NULL DEFAULT 1,
  `quantity` decimal(11,3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `seeds`
--

INSERT INTO `seeds` (`id`, `name`, `category_id`, `expiry_date`, `image`, `status`, `quantity`) VALUES
(4, 'Bell Paper', 2, '2022-02-01', 'product-1.jpg', 1, '1.000'),
(5, 'Strawberry', 3, '2022-02-09', 'product-2.jpg', 1, '0.500'),
(6, 'Green Beans', 3, '2025-02-01', 'product-3.jpg', 1, '0.700');

-- --------------------------------------------------------

--
-- Table structure for table `seed_category`
--

CREATE TABLE `seed_category` (
  `id` int(11) NOT NULL,
  `name` varchar(120) NOT NULL,
  `status` int(11) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `seed_category`
--

INSERT INTO `seed_category` (`id`, `name`, `status`) VALUES
(2, 'vegitables', 1),
(3, 'fruits', 1);

-- --------------------------------------------------------

--
-- Table structure for table `seed_inventry`
--

CREATE TABLE `seed_inventry` (
  `id` int(11) NOT NULL,
  `seed_category_id` int(11) NOT NULL,
  `seed_id` int(11) NOT NULL,
  `date` date NOT NULL,
  `time` time NOT NULL,
  `expiry_date` varchar(120) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `mobile` varchar(14) NOT NULL,
  `address` varchar(250) NOT NULL,
  `quantity` decimal(11,3) NOT NULL,
  `amount` int(11) NOT NULL,
  `invoice_number` varchar(100) NOT NULL,
  `inventory_status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `seed_inventry`
--

INSERT INTO `seed_inventry` (`id`, `seed_category_id`, `seed_id`, `date`, `time`, `expiry_date`, `name`, `email`, `mobile`, `address`, `quantity`, `amount`, `invoice_number`, `inventory_status`) VALUES
(7, 3, 5, '2022-02-08', '15:12:51', '2022-02-09', 'aksldjfl', 'fklajsldjflkj@afkjsdlf.com', '1234567890', 'klajskldfkkllasdf', '1.250', 0, 'invoice@ 78130941', 1),
(9, 3, 6, '2022-02-08', '16:56:39', '2025-02-01', 'akljsdkfl', 'fjklajlsdjfkl@flajsd.com', '584654', 'kajskd', '1.200', 0, 'invoice@ 44568471', 0),
(10, 3, 6, '2022-02-08', '17:02:05', '2025-02-01', 'sakjkldf', 'ajklfsdlfj@lfja.com', '1234567890', 'kfjsalkldfl', '3.100', 0, 'invoice@ 11278393', 0);

-- --------------------------------------------------------

--
-- Table structure for table `settings`
--

CREATE TABLE `settings` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `another_email` varchar(50) NOT NULL,
  `mobile_number` varchar(12) NOT NULL,
  `whatsapp` varchar(100) NOT NULL,
  `another_mobile` varchar(12) NOT NULL,
  `address` text NOT NULL,
  `logo` varchar(25) NOT NULL,
  `facebook` varchar(50) NOT NULL,
  `twiter` varchar(50) NOT NULL,
  `instagram` varchar(50) NOT NULL,
  `o_name` varchar(50) NOT NULL,
  `google_map` text NOT NULL,
  `top_bar_title` varchar(250) NOT NULL,
  `footer_description` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `settings`
--

INSERT INTO `settings` (`id`, `name`, `email`, `another_email`, `mobile_number`, `whatsapp`, `another_mobile`, `address`, `logo`, `facebook`, `twiter`, `instagram`, `o_name`, `google_map`, `top_bar_title`, `footer_description`) VALUES
(1, 'Vegefoods', 'demo@gmail.com', 'demo@gmail.com', '1234567890', '1234567890', '1234567890', 'addressgsfdg', 'logo.png', '#', '#', '#', 'Admin', '<iframe src=\"https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3500.60560260321!2d77.46442515095521!3d28.671525582316022!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x390cf18b19d85b49%3A0xd201c2f7c66a70f6!2sCarte%20Chowk%2C%20C%20Block%2C%20Shastri%20Nagar%2C%20Ghaziabad%2C%20Uttar%20Pradesh%20201002!5e0!3m2!1sen!2sin!4v1608975448348!5m2!1sen!2sin\" width=\"100%\" height=\"450\" frameborder=\"0\" style=\"border:0;\" allowfullscreen=\"\" aria-hidden=\"false\" tabindex=\"0\"></iframe>', '3-5 BUSINESS DAYS DELIVERY & FREE RETURNS \r\n', 'Far far away, behind the word mountains, far from the countries Vokalia and Consonantia.');

-- --------------------------------------------------------

--
-- Table structure for table `testimonials`
--

CREATE TABLE `testimonials` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `position` varchar(100) NOT NULL,
  `message` text NOT NULL,
  `image` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `testimonials`
--

INSERT INTO `testimonials` (`id`, `name`, `position`, `message`, `image`) VALUES
(1, 'Garreth Smith', 'System Analyst', 'Far far away, behind the word mountains, far from the countries Vokalia and Consonantia, there live the blind texts.', 'person_1.jpg'),
(2, 'Garreth Smith', 'Marketing Manager', 'Far far away, behind the word mountains, far from the countries Vokalia and Consonantia, there live the blind texts.', 'person_2.jpg'),
(3, 'Garreth Smith', 'Interface Designer', 'Far far away, behind the word mountains, far from the countries Vokalia and Consonantia, there live the blind texts.', 'person_3.jpg'),
(4, 'Garreth Smith', 'UI Designer', 'Far far away, behind the word mountains, far from the countries Vokalia and Consonantia, there live the blind texts.', 'person_4.jpg'),
(5, 'Garreth Smith', 'Web Developer', 'Far far away, behind the word mountains, far from the countries Vokalia and Consonantia, there live the blind texts.', 'person_1.jpg'),
(6, 'Garreth Smith', 'System Analyst', 'Far far away, behind the word mountains, far from the countries Vokalia and Consonantia, there live the blind texts.', 'person_2.jpg'),
(7, 'Garreth Smith', 'Marketing Manager', 'Far far away, behind the word mountains, far from the countries Vokalia and Consonantia, there live the blind texts.', 'person_3.jpg'),
(8, 'Garreth Smith', 'System Analyst', 'Far far away, behind the word mountains, far from the countries Vokalia and Consonantia, there live the blind texts.', 'person_4.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `mobile` varchar(14) NOT NULL,
  `password` varchar(100) NOT NULL,
  `access` int(11) NOT NULL DEFAULT 2,
  `status` int(11) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `address` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `mobile`, `password`, `access`, `status`, `created_at`, `address`) VALUES
(2, 'gardner', 'gardner@gmail.com', '123456789', '123', 3, 1, '2022-02-04 09:09:46', 'this is my address'),
(3, 'employee', 'employee@gmail.com', '1234567890', '123', 2, 1, '2022-02-04 09:10:37', 'this is my address'),
(7, 'Admin', 'admin@gmail.com', '1234567890', 'admin', 1, 1, '2022-02-04 11:34:27', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `carousel`
--
ALTER TABLE `carousel`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`category_id`),
  ADD UNIQUE KEY `unique` (`category_name`);

--
-- Indexes for table `feedback`
--
ALTER TABLE `feedback`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `footer_links`
--
ALTER TABLE `footer_links`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `images`
--
ALTER TABLE `images`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `menu`
--
ALTER TABLE `menu`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pages`
--
ALTER TABLE `pages`
  ADD PRIMARY KEY (`p_id`);

--
-- Indexes for table `seeds`
--
ALTER TABLE `seeds`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `seed_category`
--
ALTER TABLE `seed_category`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `seed_inventry`
--
ALTER TABLE `seed_inventry`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `invoice_number` (`invoice_number`);

--
-- Indexes for table `settings`
--
ALTER TABLE `settings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `testimonials`
--
ALTER TABLE `testimonials`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `carousel`
--
ALTER TABLE `carousel`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `category_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT for table `feedback`
--
ALTER TABLE `feedback`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `footer_links`
--
ALTER TABLE `footer_links`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `images`
--
ALTER TABLE `images`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `menu`
--
ALTER TABLE `menu`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `pages`
--
ALTER TABLE `pages`
  MODIFY `p_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `seeds`
--
ALTER TABLE `seeds`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `seed_category`
--
ALTER TABLE `seed_category`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `seed_inventry`
--
ALTER TABLE `seed_inventry`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `settings`
--
ALTER TABLE `settings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `testimonials`
--
ALTER TABLE `testimonials`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
